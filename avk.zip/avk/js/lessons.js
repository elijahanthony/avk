
/**
 * Function is called each time user arrives on homepage.
 */
function clearSession() {
	window.sessionStorage.clear();
}

function createVideoDialog(windowTitle, posterFile, videoFile, videoFileWebm, videoFileOgv) {
    $.Dialog({
        overlay: true,
		width: 656,
		draggable: true,
        shadow: true,
        flat: false,
        icon: '<span class="icon-youtube"></span>',
        title: windowTitle,
        content: '',
        onShow: function(_dialog){
            var html = [
                '<video width="640" height="360" id="videoPlayer" poster="' + posterFile + '" controls="controls" preload="none">' +
					// MP4 source must come first for iOS
					'<source type="video/mp4" src="' + videoFile + '" />' +
					// WebM for Firefox 4 and Opera
					'<source type="video/webm" src="' + videoFileWebm + '" />' +
					// OGG for Firefox 3 
					'<source type="video/ogg" src="' + videoFileOgv + '" />' +
					// Fallback flash player for no-HTML5 browsers with JavaScript turned off
					'<object width="640" height="360" type="application/x-shockwave-flash" data="../build/flashmediaelement.swf">' +	
						'<param name="movie" value="../build/flashmediaelement.swf" />' +
						'<param name="flashvars" value="controls=true&poster=' + posterFile + '&file=' + videoFile + '" />' +	
						// Image fall back for non-HTML5 browser with JavaScript turned off and no Flash player installed 
						'<img src="' + posterFile + '" width="640" height="360" alt="Here we are" ' +
							'title="No video playback capabilities" />' +
					'</object>' +
				'</video>'
            ].join("");
 
            $.Dialog.content(html);
        }
    });
	$('.content').addClass('bg-black');
	$('audio,video').mediaelementplayer();
}

$("#playLesson1Video1").on('click', function(){
	// formats: jpg, mp4, webm, ogg
	createVideoDialog('Taking Proper Safety Precautions When Painting', 'images/video-poster-file.jpg', 'videos/Lesson 1 - Safety Precautions.mp4', 
		'videos/Lesson 1 - Safety Precautions.webm', 'videos/Lesson 1 - Safety Precautions.ogv');
});

$("#playLesson1Video2").on('click', function(){
	// video formats: mp4, webm, ogg
	createVideoDialog('Heavy Duty Precision Lathe Machine', 'images/video-poster-file.jpg',
		'videos/lesson-1-heavy-duty-precision-lathe-machine.mp4', 'videos/lesson-1-heavy-duty-precision-lathe-machine.webm',
		'videos/lesson-1-heavy-duty-precision-lathe-machine.ogv');
});

$("#playLesson2Video1").on('click', function(){
	// video formats: mp4, webm, ogg
	createVideoDialog('Parts of an Engine Lathe', 'images/video-poster-file.jpg', 'videos/lesson-2-parts-of-an-engine-lathe.mp4',
		'videos/lesson-2-parts-of-an-engine-lathe.webm', 'videos/lesson-2-parts-of-an-engine-lathe.ogv');
});

$("#playLesson3Video1").on('click', function(){
	// video formats: mp4, webm, ogg
	createVideoDialog('Blaser Cutting Fluid Monitoring and Maintenance', 'images/video-poster-file.jpg', 
		'videos/lesson-3-blaser-cutting-fluid-monitoring-and-maintenance.mp4',
		'videos/lesson-3-blaser-cutting-fluid-monitoring-and-maintenance.webm',
		'videos/lesson-3-blaser-cutting-fluid-monitoring-and-maintenance.ogv');
});

$("#playLesson5Video1").on('click', function(){
	// video formats: mp4, webm, ogg
	createVideoDialog('Centre Lathe (Metal)', 'images/video-poster-file.jpg', 
		'videos/lesson-5-centre-lathe-metal.mp4', 'videos/lesson-5-centre-lathe-metal.webm', 'videos/lesson-5-centre-lathe-metal.ogv');
});

$("#playLesson9Video1").on('click', function(){
	// video formats: mp4, webm, ogg
	createVideoDialog('Drop Forging with Beche KGH 8.0 B', 'images/video-poster-file.jpg', 
		'videos/lesson-9-drop-forging-with-beche-kgh-8.0-b.mp4', 'videos/lesson-9-drop-forging-with-beche-kgh-8.0-b.webm',
		'videos/lesson-9-drop-forging-with-beche-kgh-8.0-b.ogv');
});

$(".nextQuizPage").on('click', function(){
	var pageUrl = location.href;
	var currentPage = pageUrl.substring(pageUrl.lastIndexOf("/")+1, pageUrl.lastIndexOf(".html"));
	
	// array format ["quiz page", "correct answer to question", "return page for incorrect answer", "next quiz page"]
	var quizPages = [
		['lesson-1-quiz-1', 'b', 'lesson-1', 'lesson-1-quiz-2'],		['lesson-1-quiz-2', 'd', 'lesson-1', 'lesson-1-quiz-3'],
		['lesson-1-quiz-3', 'd', 'lesson-1', 'lesson-1-quiz-4'],		['lesson-1-quiz-4', 'c', 'lesson-1', 'lesson-1-quiz-5'],
		['lesson-1-quiz-5', 'a', 'lesson-1', 'lesson-1-quiz-6'],		['lesson-1-quiz-6', 'c', 'lesson-1', 'lesson-1-quiz-7'],
		['lesson-1-quiz-7', 'b', 'lesson-1', 'lesson-1-quiz-8'],		['lesson-1-quiz-8', 'b', 'lesson-1', 'lesson-1-quiz-9'],
		['lesson-1-quiz-9', 'c', 'lesson-1', 'lesson-1-quiz-10'],		['lesson-1-quiz-10', 'd', 'lesson-1', 'lesson-1-quiz-outro'],
		
		['lesson-2-quiz-1', 'a', 'lesson-2', 'lesson-2-quiz-2'],		['lesson-2-quiz-2', 'c', 'lesson-2', 'lesson-2-quiz-3'],
		['lesson-2-quiz-3', 'c', 'lesson-2', 'lesson-2-quiz-4'],		['lesson-2-quiz-4', 'b', 'lesson-2', 'lesson-2-quiz-5'],
		['lesson-2-quiz-5', 'b', 'lesson-2', 'lesson-2-quiz-6'],		['lesson-2-quiz-6', 'b', 'lesson-2', 'lesson-2-quiz-7'],
		['lesson-2-quiz-7', 'd', 'lesson-2', 'lesson-2-quiz-8'],		['lesson-2-quiz-8', 'c', 'lesson-2', 'lesson-2-quiz-9'],
		['lesson-2-quiz-9', 'd', 'lesson-2', 'lesson-2-quiz-10'],		['lesson-2-quiz-10', 'b', 'lesson-2', 'lesson-2-quiz-outro'],
		
		['lesson-3-quiz-1', 'a', 'lesson-3', 'lesson-3-quiz-2'],		['lesson-3-quiz-2', 'a', 'lesson-3', 'lesson-3-quiz-3'],
		['lesson-3-quiz-3', 'a', 'lesson-3', 'lesson-3-quiz-4'],		['lesson-3-quiz-4', 'c', 'lesson-3', 'lesson-3-quiz-5'],
		['lesson-3-quiz-5', 'd', 'lesson-3', 'lesson-3-quiz-6'],		['lesson-3-quiz-6', 'a', 'lesson-3', 'lesson-3-quiz-7'],
		['lesson-3-quiz-7', 'b', 'lesson-3', 'lesson-3-quiz-8'],		['lesson-3-quiz-8', 'd', 'lesson-3', 'lesson-3-quiz-9'],
		['lesson-3-quiz-9', 'd', 'lesson-3', 'lesson-3-quiz-10'],		['lesson-3-quiz-10', 'a', 'lesson-3', 'lesson-3-quiz-outro'],
		
		['lesson-4-quiz-1', 'd', 'lesson-4', 'lesson-4-quiz-2'],		['lesson-4-quiz-2', 'c', 'lesson-4', 'lesson-4-quiz-3'],
		['lesson-4-quiz-3', 'a', 'lesson-4', 'lesson-4-quiz-4'],		['lesson-4-quiz-4', 'b', 'lesson-4', 'lesson-4-quiz-5'],
		['lesson-4-quiz-5', 'd', 'lesson-4', 'lesson-4-quiz-6'],		['lesson-4-quiz-6', 'd', 'lesson-4', 'lesson-4-quiz-7'],
		['lesson-4-quiz-7', 'd', 'lesson-4', 'lesson-4-quiz-8'],		['lesson-4-quiz-8', 'b', 'lesson-4', 'lesson-4-quiz-9'],
		['lesson-4-quiz-9', 'c', 'lesson-4', 'lesson-4-quiz-10'],		['lesson-4-quiz-10', 'c', 'lesson-4', 'lesson-4-quiz-outro'],
		
		['lesson-5-quiz-1', 'b', 'lesson-5', 'lesson-5-quiz-2'],		['lesson-5-quiz-2', 'a', 'lesson-5', 'lesson-5-quiz-3'],
		['lesson-5-quiz-3', 'd', 'lesson-5', 'lesson-5-quiz-4'],		['lesson-5-quiz-4', 'b', 'lesson-5', 'lesson-5-quiz-5'],
		['lesson-5-quiz-5', 'd', 'lesson-5', 'lesson-5-quiz-6'],		['lesson-5-quiz-6', 'b', 'lesson-5', 'lesson-5-quiz-7'],
		['lesson-5-quiz-7', 'a', 'lesson-5', 'lesson-5-quiz-8'],		['lesson-5-quiz-8', 'd', 'lesson-5', 'lesson-5-quiz-9'],
		['lesson-5-quiz-9', 'd', 'lesson-5', 'lesson-5-quiz-10'],		['lesson-5-quiz-10', 'a', 'lesson-5', 'lesson-5-quiz-outro'],
		
		['lesson-6-quiz-1', 'd', 'lesson-6', 'lesson-6-quiz-2'],		['lesson-6-quiz-2', 'c', 'lesson-6', 'lesson-6-quiz-3'],
		['lesson-6-quiz-3', 'd', 'lesson-6', 'lesson-6-quiz-4'],		['lesson-6-quiz-4', 'c', 'lesson-6', 'lesson-6-quiz-5'],
		['lesson-6-quiz-5', 'd', 'lesson-6', 'lesson-6-quiz-6'],		['lesson-6-quiz-6', 'c', 'lesson-6', 'lesson-6-quiz-7'],
		['lesson-6-quiz-7', 'b', 'lesson-6', 'lesson-6-quiz-8'],		['lesson-6-quiz-8', 'b', 'lesson-6', 'lesson-6-quiz-9'],
		['lesson-6-quiz-9', 'd', 'lesson-6', 'lesson-6-quiz-10'],		['lesson-6-quiz-10', 'b', 'lesson-6', 'lesson-6-quiz-outro'],
		
		['lesson-7-quiz-1', 'a', 'lesson-7', 'lesson-7-quiz-2'],		['lesson-7-quiz-2', 'b', 'lesson-7', 'lesson-7-quiz-3'],
		['lesson-7-quiz-3', 'b', 'lesson-7', 'lesson-7-quiz-4'],		['lesson-7-quiz-4', 'a', 'lesson-7', 'lesson-7-quiz-5'],
		['lesson-7-quiz-5', 'd', 'lesson-7', 'lesson-7-quiz-6'],		['lesson-7-quiz-6', 'b', 'lesson-7', 'lesson-7-quiz-7'],
		['lesson-7-quiz-7', 'c', 'lesson-7', 'lesson-7-quiz-8'],		['lesson-7-quiz-8', 'c', 'lesson-7', 'lesson-7-quiz-9'],
		['lesson-7-quiz-9', 'd', 'lesson-7', 'lesson-7-quiz-10'],		['lesson-7-quiz-10', 'b', 'lesson-7', 'lesson-7-quiz-outro'],
		
		['lesson-8-quiz-1', 'a', 'lesson-8', 'lesson-8-quiz-2'],		['lesson-8-quiz-2', 'c', 'lesson-8', 'lesson-8-quiz-3'],
		['lesson-8-quiz-3', 'b', 'lesson-8', 'lesson-8-quiz-4'],		['lesson-8-quiz-4', 'd', 'lesson-8', 'lesson-8-quiz-5'],
		['lesson-8-quiz-5', 'c', 'lesson-8', 'lesson-8-quiz-6'],		['lesson-8-quiz-6', 'b', 'lesson-8', 'lesson-8-quiz-7'],
		['lesson-8-quiz-7', 'd', 'lesson-8', 'lesson-8-quiz-8'],		['lesson-8-quiz-8', 'a', 'lesson-8', 'lesson-8-quiz-9'],
		['lesson-8-quiz-9', 'd', 'lesson-8', 'lesson-8-quiz-10'],		['lesson-8-quiz-10', 'b', 'lesson-8', 'lesson-8-quiz-outro'],
		
		['lesson-9-quiz-1', 'a', 'lesson-9', 'lesson-9-quiz-2'],		['lesson-9-quiz-2', 'a', 'lesson-9', 'lesson-9-quiz-3'],
		['lesson-9-quiz-3', 'd', 'lesson-9', 'lesson-9-quiz-4'],		['lesson-9-quiz-4', 'a', 'lesson-9', 'lesson-9-quiz-5'],
		['lesson-9-quiz-5', 'd', 'lesson-9', 'lesson-9-quiz-6'],		['lesson-9-quiz-6', 'a', 'lesson-9', 'lesson-9-quiz-7'],
		['lesson-9-quiz-7', 'b', 'lesson-9', 'lesson-9-quiz-8'],		['lesson-9-quiz-8', 'c', 'lesson-9', 'lesson-9-quiz-9'],
		['lesson-9-quiz-9', 'd', 'lesson-9', 'lesson-9-quiz-10'],		['lesson-9-quiz-10', 'a', 'lesson-9', 'lesson-9-quiz-outro'],
		
		['lesson-10-quiz-1', 'd', 'lesson-10', 'lesson-10-quiz-2'],		['lesson-10-quiz-2', 'c', 'lesson-10', 'lesson-10-quiz-3'],
		['lesson-10-quiz-3', 'c', 'lesson-10', 'lesson-10-quiz-4'],		['lesson-10-quiz-4', 'a', 'lesson-10', 'lesson-10-quiz-5'],
		['lesson-10-quiz-5', 'c', 'lesson-10', 'lesson-10-quiz-6'],		['lesson-10-quiz-6', 'b', 'lesson-10', 'lesson-10-quiz-7'],
		['lesson-10-quiz-7', 'a', 'lesson-10', 'lesson-10-quiz-8'],		['lesson-10-quiz-8', 'd', 'lesson-10', 'lesson-10-quiz-9'],
		['lesson-10-quiz-9', 'b', 'lesson-10', 'lesson-10-quiz-10'],	['lesson-10-quiz-10', 'd', 'lesson-10', 'lesson-10-quiz-outro']
	];
		
	for(var i=0; i<quizPages.length; i++) {
		if(quizPages[i][0] == currentPage) {
			var answers = document.getElementsByName("quizAnswers");
			var userHasNotSelectedAnyOption = true;
			for(var j=0; j<answers.length; j++) {
				// loop through answers and find the answer selected by user
				if(answers[j].checked) {
					// indicate that user has selected an option
					userHasNotSelectedAnyOption = false;
					// check if user selected the correct answer
					if(answers[j].value == quizPages[i][1]) {
						// if so, display message and move to the next quiz page
						notify("That is correct! Proceed to the next page.", 0);
						alert('That is correct! Proceed to the next page.');
						location.replace(quizPages[i][3]+".html");
					}
					else {
						// otherwise, display message and return to current lesson
						$.Dialog({
							padding: 10, width: 400, height: 150, overlay: true, draggable: true, shadow: true, flat: false,
							overlayClickClose: false, sysButtons: { btnClose: false },
							icon: '<span class="icon-warning"></span>', title: 'Quiz',
							content: '<p>Sorry, you got it wrong.</p><p> You will have to take this lesson again but click OK to proceed to the next question.</p>'+
								'<p class="text-center"><button id="backToLesson" class="button primary">OK</button></p>' +
								'<script language="javascript">' + 
									'$("#backToLesson").on("click", function(){ ' +
									'window.location.replace("'+ quizPages[i][3] +'.html"); ' +
								'});</script>'
						});
					}
				}
			}
			notifyIfNoOptionSelected(userHasNotSelectedAnyOption);
		}
	}
});

function notify(msg, timeout) { setTimeout(function(){ $.Notify({style: {background: 'red', color: 'white'}, content: msg}); }, timeout); }

$(".endTest").on('click', function(){
	// End test when user clicks 'Submit' button
	endTest(false);
});

function endTest(timeElapsed) {
	var pageUrl = location.href;
	var currentPage = pageUrl.substring(pageUrl.lastIndexOf("/")+1, pageUrl.lastIndexOf(".html"));
	
	var answers = document.getElementsByName("testAnswers");
	var userHasNotSelectedAnyOption = true;
	for(var j=0; j<answers.length; j++) {
		// loop through answers and find the answer selected by user
		if(answers[j].checked) {
			// indicate that user has selected an option
			userHasNotSelectedAnyOption = false;
			// then, fetch user's option, save it in the session, and move to the result page
			var selectedOption = answers[j].value;
			saveTestOption(currentPage, selectedOption);
			if(timeElapsed==true) {
				alert('Your time has elapsed! Your test will now be submitted and your result will be cummulated and displayed. Click OK to submit test.');
				location.replace("test-outro.html");
			} else {
				var submitTest = 
					confirm('Your test will now be submitted and your result will be cummulated and displayed. Click OK to submit test or Cancel to continue test.');
				if(submitTest==true) {
					location.replace("test-outro.html");
				}
			}
		}
	}
	notifyIfNoOptionSelected(userHasNotSelectedAnyOption);
}

$(".startTest").on('click', function(){
	saveTestStartTime();
});

function loadTestPages() {
	return [
		['test-1', 'test-2'],		['test-2', 'test-3'],		['test-3', 'test-4'],		['test-4', 'test-5'],
		['test-5', 'test-6'],		['test-6', 'test-7'],		['test-7', 'test-8'],		['test-8', 'test-9'],
		['test-9', 'test-10'],		['test-10', 'test-11'],		['test-11', 'test-12'],		['test-12', 'test-13'],
		['test-13', 'test-14'],		['test-14', 'test-15'],		['test-15', 'test-16'],		['test-16', 'test-17'],
		['test-17', 'test-18'],		['test-18', 'test-19'],		['test-19', 'test-20'],		['test-20', 'test-21'],
		['test-21', 'test-22'],		['test-22', 'test-23'],		['test-23', 'test-24'],		['test-24', 'test-25'],
		['test-25', 'test-26'],		['test-26', 'test-27'],		['test-27', 'test-28'],		['test-28', 'test-29'],
		['test-29', 'test-30'],		['test-30', 'test-31'],		['test-31', 'test-32'],		['test-32', 'test-33'],
		['test-33', 'test-34'],		['test-34', 'test-35'],		['test-35', 'test-36'],		['test-36', 'test-37'],
		['test-37', 'test-38'],		['test-38', 'test-39'],		['test-39', 'test-40']
		];
}

function loadRandomTestPages() {
	var pages = ['test-1_2','test-2_2','test-3_2','test-4_2',
				 'test-5_2','test-6_2','test-7_2','test-8_2',
				 'test-9_2','test-10_2','test-11_2','test-12_2',
				 'test-13_2','test-14_2','test-15_2','test-16_2',
				 'test-17_2','test-18_2','test-19_2','test-20_2',
				 'test-21_2','test-22_2','test-23_2','test-24_2',
				 'test-25_2','test-26_2','test-27_2','test-28_2',
				 'test-29_2','test-30_2','test-31_2','test-32_2',
				 'test-33_2','test-34_2','test-35_2','test-36_2',
				 'test-37_2','test-38_2','test-39_2','test-40_2'];
				 
	var randomTestPages = [];
	// select one item from array
	var currentPage = pages[Math.floor(Math.random() * pages.length)];
	// remove first selected item from 'pages' array
	var index = pages.indexOf(currentPage);
	if (index > -1) {
		pages.splice(index, 1);
	}
	for( ; pages.length>0; ) {
		// select another item from array
		var nextPage = pages[Math.floor(Math.random() * pages.length)];
		// add selected items to array: ['test-?current', 'test-?next'])
		var randomCurrentAndNextPage = [currentPage, nextPage];
		// replace currentPage with nextPage for next iteration
		currentPage = nextPage;
		// add array to bigger array
		randomTestPages.push(randomCurrentAndNextPage);
		// remove the other selected item from 'pages' array
		index = pages.indexOf(nextPage);
		if (index > -1) {
			pages.splice(index, 1);
		}
	}
	return randomTestPages;
}

function saveTestOption(question, selectedOption) {
	// example values test-x, a
	window.sessionStorage.setItem(question, selectedOption);
}

function readTestOption(question) {
	// example value test-x
	return window.sessionStorage.getItem(question);
}

$(".previousTestPage").on('click', function() {
	scrollTestPage('previous');
});

$(".nextTestPage").on('click', function() {
	scrollTestPage('next');
});

/**
 * This function is called on every test page, each time a test is loaded.
 * It updates the timer, and sets the option to the selected option.
 */
function initTestPage() {
	setTestPageCountdownTimer();
	setTestPageOption();
}

function setTestPageCountdownTimer() {
	var testStartTime = new Date(readTestStartTime());
	// countdownTime value: 40 minutes from current time
	var countdownTime = getTestStopTime();
	$("#test-timer").attr("data-stoptimer", countdownTime);
	$("#test-timer").countdown({
		onstop: function(){
			// End test when time elapses
			endTest(true);
		}
	});
}

function getTestStopTime() {
	// calculate stop time as current time + 40 minutes + an extra 10 seconds for convenience
	var stopTime = parseInt(readTestStartTime()) + (1000 * 60 * 40) + (1000 * 10);
	return stopTime;
}

function saveTestStartTime() {
	window.sessionStorage.setItem('test-start-time', (new Date()).getTime());
	
//	alert(new Date(getTestStopTime()));
}

function readTestStartTime() {
	return window.sessionStorage.getItem('test-start-time');
}

function setTestPageOption() {
	var pageUrl = location.href;
	var currentPage = pageUrl.substring(pageUrl.lastIndexOf("/")+1, pageUrl.lastIndexOf(".html"));
	var selectedOption = readTestOption(currentPage);
	var answers = document.getElementsByName("testAnswers");
	for(var j=0; j<answers.length; j++) {
		// loop through answers and find the answer previously selected by user
		if(answers[j].value==selectedOption) {
			// and select that option
			answers[j].checked = true;
		}
	}
}

$(".openFromTableOfContents").on('click', function() {
	var selectedContentPage = $(this).data("page");
	loadTableOfContents(selectedContentPage);
});

function loadContentsPagesKeys() {
	return [
		// array format: ["content page", "access key (password)", "page to redirect to"]
		['L1', 'ILM AB1', 'lesson-1'],
		['L1Q1', 'ILM AB1', 'lesson-1-quiz-1'],
		['L2', 'PLM XY2', 'lesson-2'],
		['L2Q2', 'PLM XY2', 'lesson-2-quiz-1'],
		['L3', 'CF PM3', 'lesson-3'],
		['L3Q3', 'CF PM3', 'lesson-3-quiz-1'],
		['L4', 'BTO TL4', 'lesson-4'],
		['L4Q4', 'BTO TL4', 'lesson-4-quiz-1'],
		['L5', 'WHD AM5', 'lesson-5'],
		['L5Q5', 'WHD AM5', 'lesson-5-quiz-1'],
		['L6', 'IMF MC6', 'lesson-6'],
		['L6Q6', 'IMF MC6', 'lesson-6-quiz-2'],
		['L7', 'FET HT7', 'lesson-7'],
		['L7Q7', 'FET HT7', 'lesson-7-quiz-7'],
		['L8', 'FET EA8', 'lesson-8'],
		['L8Q8', 'FET EA8', 'lesson-8-quiz-8'],
		['L9', 'MF AC9', 'lesson-9'],
		['L9Q9', 'MF AC9', 'lesson-9-quiz-9'],
		['L10', 'BFO LM10', 'lesson-10'],
		['L10Q10', 'BFO LM10', 'lesson-10-quiz-10'],
		['GMWAT', 'GMWAT FS11', 'test-intro'],
		['GMWRET', 'GMWRET JM12', 'test-intro']
	];
}

function loadTableOfContents(selectedContentPage) {
	if(selectedContentPage) {
		var contentsPagesKeys = loadContentsPagesKeys();
		//var keyEnteredByUser = prompt("Please enter key:", "");
		
		for(var i=0; i<contentsPagesKeys.length; i++) {
			// check which content page the user wants to access
			if(contentsPagesKeys[i][0] == selectedContentPage) {
				// then check if user has supplied an accurate key
				//if(keyEnteredByUser.toLowerCase() == contentsPagesKeys[i][1].toLowerCase()) {
					// do something special for GMWAT and GMWRET
					if(contentsPagesKeys[i][0] == 'GMWAT') window.sessionStorage.setItem('TestType', 'GMWAT');
					else if(contentsPagesKeys[i][0] == 'GMWRET') window.sessionStorage.setItem('TestType', 'GMWRET');
					// if the user has supplied an accurate key, display the appropriate page
					location.replace(contentsPagesKeys[i][2]+".html");
				//} else {
					// otherwise, inform the user that the key entered is incorrect.
					//doLog('Sorry! That key is incorrect.');
				//}
			}
		}
		
	}
}

function scrollTestPage(page) {
	var pageUrl = location.href;
	var currentPage = pageUrl.substring(pageUrl.lastIndexOf("/")+1, pageUrl.lastIndexOf(".html"));
	
	var currentPageIndex, newPageIndex;
	if(page=='next') { currentPageIndex = 0; newPageIndex = 1; }
	else if(page=='previous') { currentPageIndex = 1; newPageIndex = 0; }
	
	// array format
	// for nextTestPage ["test page", "next test page"]
	// for previousTestPage ["previous test page", "test page"]
	var testPages = []; //loadRandomTestPages(); //loadTestPages();
	
	var testType = window.sessionStorage.getItem('TestType');
	
	if(testType == 'GMWAT') testPages = loadTestPages();
	else if(testType == 'GMWRET') testPages = JSON.parse(window.sessionStorage.getItem('RandomTestPages'));
	
	for(var i=0; i<testPages.length; i++) {
		if(testPages[i][currentPageIndex] == currentPage) {
			var answers = document.getElementsByName("testAnswers");
			var userHasNotSelectedAnyOption = true;
			for(var j=0; j<answers.length; j++) {
				// loop through answers and find the answer selected by user
				if(answers[j].checked) {
					// indicate that user has selected an option
					userHasNotSelectedAnyOption = false;
					// then, fetch user's option, save it in the session, and move to the next test page
					var selectedOption = answers[j].value;
					// check if this is not the first test page
					saveTestOption(currentPage, selectedOption);
					location.replace(testPages[i][newPageIndex]+".html");
				}
			}
			notifyIfNoOptionSelected(userHasNotSelectedAnyOption);
		}
	}
}

function notifyIfNoOptionSelected(noOptionSelected) {
	if(noOptionSelected) {
		notify("You have not yet selected any option . . . . .", 0);
		notify("Please select an answer before proceeding.", 800);
	}
}

/** 
 * This function checks if the user is on "current lesson page",
 * and moves to the "next lesson page" or the "previous lesson page".
 *
 * Multi-level array format:
 * for nextLessonPage [["current lesson page", "next lesson page"]...]
 * for previousLessonPage [["previous lesson page", "current lesson page"]...]
 */
function loadLessonPages() {
	var randomTestPages = loadRandomTestPages();
	window.sessionStorage.setItem('RandomTestPages', JSON.stringify(randomTestPages));
	
	var firstTestPage = '';
	if(randomTestPages.length > 0 && randomTestPages[0].length > 0) {
		firstTestPage = randomTestPages[0][0];
	}
	var testType = window.sessionStorage.getItem('TestType');
	if(testType == 'GMWAT') firstTestPage = 'test-1';
	
	var lessonPages = [
		['lesson-1', 'lesson-1-1'],					['lesson-1-1', 'lesson-1-2'],					['lesson-1-2', 'lesson-1-3'],
		['lesson-1-3', 'lesson-1-4'],				['lesson-1-4', 'lesson-1-5'],					['lesson-1-5', 'lesson-1-6'],
		['lesson-1-6', 'lesson-1-7'],				['lesson-1-7', 'lesson-1-quiz-intro'],			['lesson-1-quiz-intro', 'lesson-1-quiz-1'],
		['lesson-1-quiz-outro', 'lesson-2'],
		
		['lesson-2', 'lesson-2-1'],					['lesson-2-1', 'lesson-2-2'],					['lesson-2-2', 'lesson-2-3'],
		['lesson-2-3', 'lesson-2-4'],				['lesson-2-4', 'lesson-2-quiz-intro'],					['lesson-2-quiz-intro', 'lesson-2-quiz-1'],
		['lesson-2-quiz-outro', 'lesson-3'],		
		
		['lesson-3', 'lesson-3-1'],					['lesson-3-1', 'lesson-3-2'],					['lesson-3-2', 'lesson-3-3'],
		['lesson-3-3', 'lesson-3-4'],				['lesson-3-4', 'lesson-3-quiz-intro'],					['lesson-3-quiz-intro', 'lesson-3-quiz-1'],
		['lesson-3-quiz-outro', 'lesson-4'],		
		
		['lesson-4', 'lesson-4-1'],					['lesson-4-1', 'lesson-4-2'],					['lesson-4-2', 'lesson-4-3'],
		['lesson-4-3', 'lesson-4-4'],				['lesson-4-4', 'lesson-4-quiz-intro'],					['lesson-4-quiz-intro', 'lesson-4-quiz-1'],
		['lesson-4-quiz-outro', 'lesson-5'],		
		
		['lesson-5', 'lesson-5-1'],					['lesson-5-1', 'lesson-5-2'],					['lesson-5-2', 'lesson-5-3'],
		['lesson-5-3', 'lesson-5-4'],				['lesson-5-4', 'lesson-5-5'],					['lesson-5-5', 'lesson-5-6'],
		['lesson-5-6', 'lesson-5-quiz-intro'],				['lesson-5-quiz-intro', 'lesson-5-quiz-1'],					['lesson-5-quiz-1', 'lesson-5-quiz-outro'],
		['lesson-6', 'lesson-6'],
		
		['lesson-6', 'lesson-6-1'],					['lesson-6-1', 'lesson-6-2'],					['lesson-6-2', 'lesson-6-3'],
		['lesson-6-3', 'lesson-6-4'],				['lesson-6-4', 'lesson-6-5'],					['lesson-6-5', 'lesson-6-quiz-intro'],
		['lesson-6-quiz-intro', 'lesson-6-quiz-1'],				['lesson-6-quiz-1', 'lesson-6-quiz-outro'],			['lesson-6-quiz-outro', 'lesson-7'],
		
		
		['lesson-7', 'lesson-7-1'],					['lesson-7-1', 'lesson-7-2'],					['lesson-7-2', 'lesson-7-3'],
		['lesson-7-3', 'lesson-7-4'],				['lesson-7-4', 'lesson-7-5'],					['lesson-7-5', 'lesson-7-6'],
		['lesson-7-6', 'lesson-7-7'],				['lesson-7-7', 'lesson-7-8'],					['lesson-7-8', 'lesson-7-quiz-intro'],
		['lesson-7-quiz-intro', 'lesson-7-quiz-1'], ['lesson-7-quiz-outro', 'lesson-8'],
		
		['lesson-8', 'lesson-8-1'],					['lesson-8-1', 'lesson-8-2'],					['lesson-8-2', 'lesson-8-3'],
		['lesson-8-3', 'lesson-8-4'],				['lesson-8-4', 'lesson-8-5'],					['lesson-8-5', 'lesson-8-6'],
		['lesson-8-6', 'lesson-8-7'],				['lesson-8-7', 'lesson-8-8'],					['lesson-8-8', 'lesson-8-9'],
		['lesson-8-9', 'lesson-8-10'],				['lesson-8-10', 'lesson-8-11'],					['lesson-8-11', 'lesson-8-12'],
		['lesson-8-12', 'lesson-8-13'],				['lesson-8-13', 'lesson-8-14'],					['lesson-8-14', 'lesson-8-quiz-intro'],
		['lesson-8-quiz-intro', 'lesson-8-quiz-1'],	['lesson-8-quiz-outro', 'lesson-9'],
		
		['lesson-9', 'lesson-9-1'],					['lesson-9-1', 'lesson-9-2'],					['lesson-9-2', 'lesson-9-3'],
		['lesson-9-3', 'lesson-9-4'],				['lesson-9-4', 'lesson-9-5'],					['lesson-9-5', 'lesson-9-quiz-intro'],
		['lesson-9-quiz-intro', 'lesson-9-quiz-1'],	['lesson-9-quiz-outro', 'lesson-10'],
		
		['lesson-10', 'lesson-10-1'],				['lesson-10-1', 'lesson-10-2'],					['lesson-10-2', 'lesson-10-3'],
		['lesson-10-3', 'lesson-10-4'],				['lesson-10-4', 'lesson-10-5'],					['lesson-10-5', 'lesson-10-6'],
		['lesson-10-6', 'lesson-10-7'],				['lesson-10-7', 'lesson-10-8'],					['lesson-10-8', 'lesson-10-9'],
		['lesson-10-9', 'lesson-10-10'],			['lesson-10-10', 'lesson-10-11'],				['lesson-10-11', 'lesson-10-12'],
		['lesson-10-12', 'lesson-10-13'],			['lesson-10-13', 'lesson-10-14'],				['lesson-10-14', 'lesson-10-15'],
		['lesson-10-15', 'lesson-10-quiz-intro'],	['lesson-10-quiz-intro', 'lesson-10-quiz-1'],	['table-of-contents', 'test-intro'],
		
		['test-intro', firstTestPage],
		['test-outro', 'index']
	];
		
	return lessonPages;
}

$(".tableOfContents").on('click', function(){
	location.href = 'table-of-contents.html';
});

$(".previousLessonPage").on('click', function(){
	var pageUrl = location.href;
	var currentPage = pageUrl.substring(pageUrl.lastIndexOf("/")+1, pageUrl.lastIndexOf(".html"));
	
	var lessonPages = loadLessonPages();
		
	for(var i=0; i<lessonPages.length; i++) {
		if(lessonPages[i][1] == currentPage) {
			location.href = lessonPages[i][0]+".html";
		}
	}
});

$(".nextLessonPage").on('click', function(){
	var pageUrl = location.href;
	var currentPage = pageUrl.substring(pageUrl.lastIndexOf("/")+1, pageUrl.lastIndexOf(".html"));
	
	var lessonPages = loadLessonPages();
	
	for(var i=0; i<lessonPages.length; i++) {
		if(lessonPages[i][0] == currentPage) {
			location.href = lessonPages[i][1]+".html";
		}
	}
});

$("#homePage").on('click', function(){
	var pageUrl = location.href;
	// check if current page is not a quiz or test page
	// (quiz or test intro and outro pages are not considered quiz or test pages,
	// since the user has either not started the quiz or test, or the user has already finished)
	if( pageUrl.indexOf("quiz") == -1       || pageUrl.indexOf("test") == -1       || 
		pageUrl.indexOf("quiz-intro") != -1 || pageUrl.indexOf("quiz-outro") != -1 || 
		pageUrl.indexOf("test-intro") != -1 || pageUrl.indexOf("test-outro") != -1 ) {
		// if so, redirect to home page
		location.href='index.html';
	} else {
		// otherwise, display message and don't redirect
		notify("You can not go to the home page in the middle of a quiz!", 0);
	}
});

/**
 * This function mails the test score,
 * and then displays that score.
 */
function processTestResults() {
	var pageUrl = location.href;
	
	var testKey = ['C', 'D', 'D', 'A', 'A', 'B', 'D', 'A', 'D', 'A', 
					'D', 'D', 'A', 'D', 'B', 'B', 'D', 'D', 'C', 'B', 
					'B', 'D', 'C', 'D', 'A', 'B', 'A', 'D', 'A', 'D', 
					'C', 'D', 'A', 'C', 'D', 'B', 'D', 'D', 'C', 'A'];
	
	var score = 0;
	for(var i=1; i<40; i++) {
		var page = 'test-'+i;
		var testOption = readTestOption(page);
		if(testOption===null) { page = 'test-'+i+'_2'; testOption = readTestOption(page); }
		if((testOption+'').toLowerCase() == testKey[i-1].toLowerCase()) {
			score++;
		}
	}
	
	mailTestScore(score);
	displayScore(score);
}

function displayScore(score) {
	var percentage = (score/40)*100;
	var progressBarColor = '', statusBg = '', statusMsg = '';
	
	$("#score").html(percentage + '%');
	$("#scoreProgressBar").attr('data-value', percentage);
	if(percentage >= 50) {
		progressBarColor = 'bg-green';
		statusBg = 'ribbed-green';
		statusMsg = 'You passed';
	} else {
		progressBarColor = 'bg-red';
		statusBg = 'ribbed-red';
		statusMsg = 'You failed';
	}
	$("#scoreProgressBar").attr('data-color', progressBarColor);
	
	$("#statusMessageBox").addClass(statusBg);
	$("#statusMessage").html(statusMsg);
	
	$("#questionsPassed").html(score);
	$("#questionsFailed").html(40 - score);
}

$(".sendMessage").on('click', function(){
	$.Dialog({
		padding: 10,
		overlay: true,
		draggable: true,
		shadow: true,
		flat: false,
		overlayClickClose: false,
		icon: '<span class="icon-comments"></span>',
		title: 'Contact us',
		content: '',
        onShow: function(_dialog){
            var html = [
                '<iframe width="635" height="340" src="send-message.html" frameborder="0"></iframe>'
            ].join("");
 
            $.Dialog.content(html);
        }
	});
});

$(".startLessons").on('click', function(){
	$.Dialog({
		padding: 10,
		height: 500,
		overlay: true,
		draggable: true,
		shadow: true,
		flat: false,
		overlayClickClose: false,
		icon: '<span class="icon-enter"></span>',
		title: 'Welcome',
		content: '',
        onShow: function(_dialog){
            var html = [
                '<iframe width="640" height="480" src="login.html" frameborder="0"></iframe>'
            ].join("");
 
            $.Dialog.content(html);
        }
	});
});

$("#messageForm").on('submit', function() {
	if(validateMessage()) {
		sendMessage();
	}
		
	return false; // prevent normal form submission
});

function displayUser() {
	var lblUser = document.getElementById('lblUser');
	lblUser.innerHTML = window.sessionStorage.getItem('username');
}

function checkLoggedIn() {
	if(notLoggedIn()) {
		alert('You are not currently logged in. Your session might have ended. Please login to continue.');
		returnToHomepage();
	} else {
		var lblUser = document.getElementById('lblUser');
		lblUser.innerHTML = window.sessionStorage.getItem('firstName') + ' ' + window.sessionStorage.getItem('lastName');
	}
}

function returnToHomepage() {
	window.location.href = 'index.html';
}

function notLoggedIn() {
	return window.sessionStorage.getItem('email')==null || window.sessionStorage.getItem('email')==undefined;
}

$("#loginForm").on('submit', function() {
	if(validateLogin()) {
		webSQL.findRecord();
	}
		
	return false; // prevent normal form submission
});

$("#signUpForm").on('submit', function() {
	if(validateSignUp()) {
		webSQL.createTable();
		webSQL.insertRecord();
	}
		
	return false; // prevent normal form submission
});

function doLog(msg) {
	notify(msg, 0);
	var dblog = document.getElementById('db-log');
	if(dblog!=null && dblog!=undefined)
		dblog.innerHTML = msg;
	return msg;
}

function sendMessage() {
	doLog('Sending message... please wait');
	
	var data = {
		firstName: $("#firstName").val(),
		lastName: $("#lastName").val(),
		email: $("#email").val(),
		message: $("#message").val(),
		phoneNumber: $("#phoneNumber").val()
	};
	$.ajax({
		type: "POST",
		url: "http://paintinganddecorating.com.ng/mailer.php",
		data: data,
		success: function(data, textStatus, jqXHR) {
			doLog('Your message has been sent.');
			$('#messageForm').fadeOut(1000);
		},
		error: function(jqXHR, textStatus, errorThrown) {
			doLog('Your message could not be sent.');
			doLog('Please check your internet connection and try again.');
		},
		complete: function() {
			// do nothing
		}
	});
}

function mailTestScore(score) {
	doLog('Sending test score... please wait');
	
	var data = {
		firstName: window.sessionStorage.getItem('firstName'),
		lastName: window.sessionStorage.getItem('lastName'),
		email: window.sessionStorage.getItem('email'),
		phoneNumber: window.sessionStorage.getItem('phoneNumber'),
		score: score,
		TestType: window.sessionStorage.getItem('TestType')
	};
	$.ajax({
		type: "POST",
		url: "http://paintinganddecorating.com.ng/mail-test-score.php",
		data: data,
		success: function(data, textStatus, jqXHR) {
			doLog('Your test score has been sent.');
		},
		error: function(jqXHR, textStatus, errorThrown) {
			doLog('Your test score could not be sent.');
			doLog('Please contact the administrator.');
			console.log(jqXHR);
			console.log(textStatus);
			console.log(errorThrown);
		},
		complete: function() {
			// do nothing
		}
	});
}

function validateMessage() {
	var validated = true;
	fieldValidates('#firstName', '', "Please enter your first name.") 					? 0 : validated=false;
	fieldValidates('#lastName', '', "Please enter your last name.") 					? 0 : validated=false;
	fieldValidates('#email', '', "Please enter your email address.") 					? 0 : validated=false;
	fieldValidates('#message', '', "Please enter your message, request or comments.")	? 0 : validated=false;
	
	return validated;
}

function validateLogin() {
	var validated = true;
	fieldValidates('#lusername', '', "Please enter your username.") 	? 0 : validated=false;
	fieldValidates('#lpassword', '', "Please enter your password.") 	? 0 : validated=false;
	
	return validated;
}

function validateSignUp() {
	var validated = true;
	fieldValidates('#firstName', '', "Please enter your first name.") 			? 0 : validated=false;
	fieldValidates('#lastName', '', "Please enter your last name.") 			? 0 : validated=false;
	fieldValidates('#gender', 'none', "Please select your gender.") 			? 0 : validated=false;
	fieldValidates('#username', '', "Please enter your preferred username.") 	? 0 : validated=false;
	fieldValidates('#email', '', "Please enter your email address.") 			? 0 : validated=false;
	fieldValidates('#password', '', "Please enter your preferred password.") 	? 0 : validated=false;
	fieldValidates('#reTypePassword', '', "Please retype your password.") 		? 0 : validated=false;
	
	var pwd = document.querySelector('#password').value;
	var reTypePwd = document.querySelector('#reTypePassword').value;
	if(pwd!=reTypePwd) {
		var errorMsg = "Your password does not match. Please check.";
		doLog(errorMsg);
		validated = false;
	}
	
	return validated;
}

function fieldValidates(field, value, errorMsg) {
	// if field does not validate
	if(document.querySelector(field).value==value) {
		// display error message and return false
		doLog(errorMsg);
		return false;
	}
	// otherwise return true
	return true;
}

function setAsCurrentlyLoggedInUser(username, firstName, lastName, email, phoneNumber) {
	try {
		window.sessionStorage.setItem('username', username);
		window.sessionStorage.setItem('firstName', firstName);
		window.sessionStorage.setItem('lastName', lastName);
		window.sessionStorage.setItem('email', email);
		window.sessionStorage.setItem('phoneNumber', phoneNumber);
	} catch(e) {
		alert('This browser is not supported.\nWe recommend the latest version of Google Chrome.');
		console.log(e);
		return false;
	}
}

function displayPleaseWaitWithMessage(msg) {
	doLog(msg);
	$.Dialog({title: 'please wait', padding: 4, width: 200, height: 60, overlayClickClose: false,
		sysButtons: { btnClose: false },
		content: '<p class="text-center">redirecting... please wait<br><progress>please wait</progress></p>'
	});
}

var webSQL = (function() {
	var db;
	if (window.openDatabase) {
		db = openDatabase("GeneralMetalworkDB", "1.0", "Database for General Metalwork users", 200000);
	} else {
		doLog('This browser is not supported');
		doLog('We recommend the latest version of Google Chrome');
		doLog('<a href="https://www.google.com/chrome/" target="_blank" class="fg-white"><u>Click here to download and install Google Chrome</u></a>');
		alert('This browser is not supported.\nWe recommend the latest version of Google Chrome.');
	}

	function onError(tx, error) {
		// check if error is related to unique constraint (duplicate username)
		if(error.message.indexOf('constraint')!=-1)
			// if so, display user-friendly message
			doLog('It seems like someone else has already signed up with this username. Please choose another one.');
		else if(error.message.indexOf('could not prepare statement (1 no such table: Users)')!=-1)
			// display friendly message if table has not been created
			doLog('Invalid username or password. Have you registered before? If not, use the table below.');
		else if(error.message.indexOf('could not prepare statement (1 table Users already exists)')!=-1) {}
			// display no message if table has already been created
			// doLog('Invalid username or password. Have you registered before? If not, use the table below.');
		else
			// otherwise, display error message
			doLog('Error: ' + error.message);
	}

	function createTable() {
		db.transaction(function(tx) {
			tx.executeSql("CREATE TABLE Users (id REAL UNIQUE, username TEXT UNIQUE, password TEXT, firstName TEXT, lastName TEXT, phoneNumber TEXT, email TEXT, gender TEXT)", [],
				function(tx) { doLog('<span class="fg-green">"Users" created!</span>'); },
				onError);
		});
	}
	
	function dropTable() {
		db.transaction(function(tx) {
			tx.executeSql("DROP TABLE Users", [],
				function(tx) { doLog('<span class="fg-green">"Users" dropped!</span>'); }, 
				onError);
		});
	}
	
	function findRecord() {
		var username = document.querySelector('#lusername').value;
		db.transaction(
			function(tx) {
				tx.executeSql("SELECT * FROM Users WHERE username=? AND password=?", 
				[
				username,
				document.querySelector('#lpassword').value
				],
			function(tx, result) {
				// check if a record is found for this user
				if(result.rows.length > 0) {
					// if so, set as currently logged in user, display success message and redirect
					var username = result.rows.item(0)['username'];
					var firstName = result.rows.item(0)['firstName'];
					var lastName = result.rows.item(0)['lastName'];
					var email = result.rows.item(0)['email'];
					var phoneNumber = result.rows.item(0)['phoneNumber'];
					var browserSupportsSession = setAsCurrentlyLoggedInUser(username, firstName, lastName, email, phoneNumber);
					if(browserSupportsSession==false) {return;}
					displayPleaseWaitWithMessage('Login successful. redirecting... please wait');
					setTimeout(function(){ top.location.href = 'table-of-contents.html'; }, 5000);
				} else {
					// otherwise, display error message
					doLog('Invalid username or password.');
				}
			}, 
			onError);
		});
	}

	// add record with user data
	function insertRecord() {
		var userID = Math.round(Math.random() * 10000); // generate random data for user id
		var username = document.querySelector('#username').value;
		var password = document.querySelector('#password').value;
		var firstName = document.querySelector('#firstName').value;
		var lastName = document.querySelector('#lastName').value;
		var phoneNumber = document.querySelector('#phoneNumber').value;
		var email = document.querySelector('#email').value;
		var gender = document.querySelector('#gender').value;
		db.transaction(
			function(tx) {
				tx.executeSql("INSERT INTO Users (id, username, password, firstName, " +
				"lastName, phoneNumber, email, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", 
				[userID, 
				username,
				password,
				firstName,
				lastName,
				phoneNumber,
				email,
				gender],
			function(tx, result) {
				// set as currently logged in user, display success message and redirect
				var browserSupportsSession = setAsCurrentlyLoggedInUser(username, firstName, lastName, email, phoneNumber);
				if(browserSupportsSession==false) {return;}
				displayPleaseWaitWithMessage('Sign up successful. redirecting... please wait');
				setTimeout(function(){ top.location.href = 'table-of-contents.html'; }, 5000);
			}, 
			onError);
		});
	}
	return {
		insertRecord: insertRecord,
		createTable: createTable,
		findRecord: findRecord
	}
})();