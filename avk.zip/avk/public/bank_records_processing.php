<?php
	
	session_start();


	if(isset($_POST))
	{

    require 'incfile.php';
    
  
	
		$guard_name = $_POST['guard_name'];
		//$fname = $_POST['fname'];
		$bank_name = $_POST['bank_name'];
		//$account_name = $_POST['account_name'];
		$account_number = $_POST['account_number'];
		
		

								
			$query = " UPDATE bank SET account_name = '$guard_name', account_number = '$account_number', bank_name = '$bank_name'
			WHERE
			full_name = '$guard_name'";

		if ($result = mysqli_query($db, $query))
        {

        	$_SESSION["creation-successful"] = "<h6>Thank you <br>'$guard_name' bank record is successfully updated</h6>";
	            header('Location:update_bank.php');
				exit();


        	
        }

		

		

	}

?>