<?php
	
	session_start();


	if(isset($_POST))
	{

    require 'incfile.php';


		$clients_name = $_POST['clients_name'];
		$d_o_e = $_POST['d_o_e'];
		$number_of_guards = $_POST['number_of_guards'];
		$amount_per_guard = $_POST['amount_per_guard'];
		$phone_number = $_POST['phone_number'];
		$address = $_POST['address'];
		

					
			$query = " UPDATE alpha_client SET d_o_e = '$d_o_e', number_of_guards = '$number_of_guards', amount_per_guard = '$amount_per_guard', phone_number = '$phone_number', address = '$address'
			WHERE
			clients_name = '$clients_name'";

		if ($result = mysqli_query($db, $query))
        {

        	if (mysqli_affected_rows($db) == 1) 
        	{
        		
        		$_SESSION["creation-successful"] = "<h6>Thank you <br>'$clients_name' is updated</h6>";
	            header('Location:update_client.php');
				exit();

        	}
        	else {
        		echo "Client record is not found. <br> Go back and start the process again";
        	}


        	
        }

		

		

	}

?>