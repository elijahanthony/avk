<?php
session_start();


    require 'incfile.php';
    
  
 
?>


<html>
<head>
	<title>Guard Profile <?php  echo "date_create()"; ?></title>
	<style type="text/css">
		body {
			font-size: 15px;
			color: #343d44;
			font-family: "segoe-ui", "open-sans", tahoma, arial;
			padding: 0;
			margin: 0;
		}
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;
		}

		h1 {
			margin: 25px auto 0;
			text-align: center;
			text-transform: uppercase;
			font-size: 17px;
		}

		table td {
			transition: all .5s;
		}
		
		/* Table */
		.data-table {
			border-collapse: collapse;
			font-size: 14px;
			min-width: 537px;
		}

		.data-table th, 
		.data-table td {
			border: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.data-table caption {
			margin: 7px;
		}

		/* Table Header */
		.data-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}

		/* Table Body */
		.data-table tbody td {
			color: #353535;
		}
		.data-table tbody td:first-child,
		.data-table tbody td:nth-child(4),
		.data-table tbody td:last-child {
			text-align: right;
		}

		.data-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.data-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
		}

		/* Table Footer */
		.data-table tfoot th {
			background-color: #e5f5ff;
			text-align: right;
		}
		.data-table tfoot th:first-child {
			text-align: left;
		}
		.data-table tbody td:empty
		{
			background-color: #ffcccc;
		}
	</style>
</head>
<body>
	<div><h1><b>AVK SECURITY SERVICES NIG. LTD</b></h1><br><hr>
	<!--p style="margin-left: 550px;">Updated Guard record as at today</p>
	<p style="margin-left: 300px;">Phone: +234 09 872 6062, +234 80 64736 280</p></div-->
	
	<table class="data-table">
		<caption class="title"></caption>
		<!--thead>
			 <tr>
                        
                        <th>Description</th>
                        <th>Cost per guard <br>(Monthly)</th>
                        <th>Number of guard</th>
                        <th>Amount</th>
                        
                    </tr>
		</thead-->

		<tbody>
		<?php
		$full_name = $_POST['full_name'];


		$query = "SELECT full_name_id, full_name, date_of_deployment, beat, salary, position, status FROM deployment WHERE full_name = '$full_name'";
		if($result = mysqli_query($db, $query))
		{

			
		//if ($result->num_rows > 0)
		if (mysqli_affected_rows($db) == 1) {
			echo "<div style='margin-left:500px;'><b> The Information below is the detailed information of:</b> <br><br>
			$full_name available for Operations department. <br> Visit Other departments for related Information about this guard.
			</div>";
			

					echo "<table class='data-table'><tr><th style='border=1px solid black;Font-size=18;Font-Weight=bold'>EMPLOYMENT ID</th><th>FULL NAME</th><th>DATE OF DEPLOYMENT</th><th>BEAT</th><th>SALARY</th><th>POSITION</th><th>STATUS</th></tr>";
					 			

				while($row = $result->fetch_assoc()) {
        echo "<tr><td>AVK/GUR".$row["full_name_id"]."</td><td>".$row["full_name"]." </td><td>".$row["date_of_deployment"]."</td><td>".$row["beat"]."</td><td>".$row["salary"]."</td><td>".$row["position"]."</td><td>".$row["status"]."</td></tr>";
    }

    echo "</table>";
}
		}
 else {
    echo "0 results";
}
?>
		
</body>

<div style="margin-left: 1200px;"><a href="dashboardoperations.php" class="next">Back</a></div>
<!--div style="margin-left: 300px;"><h5>Kindly pay through the account details below:<br>
NAME: AVK SECURITY SERVICES NIG.LTD <br>
BANK: UNITY<br>
ACCOUNT NO.: 0025811360
<br>
<br>
<br>

For: AVK Services Nig. Ltd</h5>
	<a href="#"><button style="margin-left: 750px;">PRINT</button></a></div-->

</html>