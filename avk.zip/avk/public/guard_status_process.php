<?php
	
	session_start(); // Carbon::today()->subtractMonths(3)->toTimeString();
	

	if(!empty($_POST))
{
	require 'incfile.php';


		$full_name = $_POST['full_name'];
		$date_status = date('Y-m-d');
		// $month = date("F",strtotime("0 month"));
		//$date_paid = $_POST['date_paid'];
		//$status= $_POST['status'];
		$status = $_POST['status'];
		//$advance = 'salary';

		//$full_name_id = $_SESSION['$full_name'];
		//$description = $_POST['description'];

		// $phone_number = $_POST['phone_number'];
		// $address = $_POST['address'];

		// RUN INSERT TO ALPHA CLIENT HERE


		// $query = "INSERT INTO alpha_guards (advance) VALUES('$advance') WHERE full_name = $full_name_id";
		// if ($result = mysqli_query($db, $query)) {
		// 	$full_name_id =  mysqli_insert_id($db);

		// }


		

		//$query = " UPDATE deployment SET status = '$status', date_status = '$date_status' WHERE full_name = '$full_name'";
		//$query = " INSERT INTO  deployment  (status) VALUES ($status) WHERE full_name = '$full_name'";
		$query = "UPDATE deployment SET status ='$status' WHERE full_name = '$full_name'";


		
		if ($result = mysqli_query($db, $query))
        {

        	if (mysqli_affected_rows($db) == 1) 
        	{
        		
        		$_SESSION["creation-successful"] = "<h6>$full_name Has Just Been declared $status on $date_status .</h6>";
	            header('Location:guard_status.php');
				exit();

        	}

        	
        }

	}

?>