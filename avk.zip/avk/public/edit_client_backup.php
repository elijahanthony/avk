<?php
session_start();


    require 'incfile.php';
  
 
?>
  

<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <!--IE Compatibility modes-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Mobile first-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Client Registeration</title>
    
    <meta name="description" content="AVK Security protects lives and property">
    <meta name="author" content="Anthony Elijah 08031925347">
    
    <meta name="msapplication-TileColor" content="#5bc0de" />
    <meta name="msapplication-TileImage" content="assets/img/metis-tile.png" />
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/lib/bootstrap/css/bootstrap.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/lib/font-awesome/css/font-awesome.css">
    
    <!-- Metis core stylesheet -->
    <link rel="stylesheet" href="assets/css/main.css">
    
    <!-- metisMenu stylesheet -->
    <link rel="stylesheet" href="assets/lib/metismenu/metisMenu.css">
    
    <!-- onoffcanvas stylesheet -->
    <link rel="stylesheet" href="assets/lib/onoffcanvas/onoffcanvas.css">
    
    <!-- animate.css stylesheet -->
    <link rel="stylesheet" href="assets/lib/animate.css/animate.css">


        <link rel="stylesheet" href="/assets/lib/inputlimiter/jquery.inputlimiter.css">
        <link rel="stylesheet" href="/assets/lib/bootstrap-daterangepicker/daterangepicker-bs3.css">
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/Uniform.js/2.1.2/themes/default/css/uniform.default.min.css">
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/chosen/1.1.0/chosen.min.css">
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery-tagsinput/1.3.3/jquery.tagsinput.css">
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/css/jasny-bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.2/css/bootstrap3/bootstrap-switch.min.css">
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.1/css/datepicker3.min.css">
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.0.1/css/bootstrap-colorpicker.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
            <script src="assets/lib/jquery/jquery.js"></script>

  </head>

        <body class="  ">
            <div class="bg-dark dk" id="wrap">
                <div id="top">
                    <!-- .navbar -->
                    <nav class="navbar navbar-inverse navbar-static-top">
                        <div class="container-fluid">
                    
                    
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <header class="navbar-header">
                    
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a href="../index.html" class="navbar-brand"><img src="../images/logo.png" alt="AVK SECURITY" style="max-width: 40px;" alt=""></a>
                    
                            </header>
                    
                    
                    
                            <div class="topnav">
                                <div class="btn-group">
                                    <a data-placement="bottom" data-original-title="Fullscreen" data-toggle="tooltip"
                                       class="btn btn-default btn-sm" id="toggleFullScreen">
                                        <i class="glyphicon glyphicon-fullscreen"></i>
                                    </a>
                                </div>
                                <div class="btn-group">
                                    <a data-placement="bottom" data-original-title="E-mail" data-toggle="tooltip"
                                       class="btn btn-default btn-sm">
                                        <i class="fa fa-envelope"></i>
                                        <span class="label label-warning">5</span>
                                    </a>
                                    <a data-placement="bottom" data-original-title="Messages" href="#" data-toggle="tooltip"
                                       class="btn btn-default btn-sm">
                                        <i class="fa fa-comments"></i>
                                        <span class="label label-danger">4</span>
                                    </a>
                                    <a data-toggle="modal" data-original-title="Help" data-placement="bottom"
                                       class="btn btn-default btn-sm"
                                       href="#helpModal">
                                        <i class="fa fa-question"></i>
                                    </a>
                                </div>
                                <div class="btn-group">
                                    <a href="login.html" data-toggle="tooltip" data-original-title="Logout" data-placement="bottom"
                                       class="btn btn-metis-1 btn-sm">
                                        <i class="fa fa-power-off"></i>
                                    </a>
                                </div>
                                <div class="btn-group">
                                    <a data-placement="bottom" data-original-title="Show / Hide Left" data-toggle="tooltip"
                                       class="btn btn-primary btn-sm toggle-left" id="menu-toggle">
                                        <i class="fa fa-bars"></i>
                                    </a>
                                    <a href="#right" data-toggle="onoffcanvas" class="btn btn-default btn-sm" aria-expanded="false">
                                        <span class="fa fa-fw fa-comment"></span>
                                    </a>
                                </div>
                    
                            </div>

                    
                    
                    
                            <div class="collapse navbar-collapse navbar-ex1-collapse">
                    
                                <!-- .nav -->
                                <ul class="nav navbar-nav">
                                    <li class="active"><a href="dashboardhr.php">Dashboard</a></li>
                                    
                                        </ul>
                                    </li-->
                                </ul>
                                <!-- /.nav -->
                            </div>
                        </div>
                        <!-- /.container-fluid -->
                    </nav>
                    <!-- /.navbar -->
                        <header class="head">
                                <div class="search-bar">
                                    <form class="main-search" action="test.php">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="Live Search ...">
                                            <span class="input-group-btn">
                                                <button class="btn btn-primary btn-sm text-muted" type="button">
                                                    <i class="fa fa-search"></i>
                                                </button>
                                            </span>
                                        </div>
                                    </form>
                                    <!-- /.main-search -->                                </div>
                                <!-- /.search-bar -->
                            <div class="main-bar">
                                <h3>
              <i class="fa fa-dashboard"></i>&nbsp;
            HR / Admin Dashboard
          </h3>
                            </div>
                            <!-- /.main-bar -->
                        </header>
                        <!-- /.head -->
                </div>
                <!-- /#top -->
                    <div id="left">
                        <div class="media user-media bg-dark dker">
                            <div class="user-media-toggleHover">
                                <span class="fa fa-user"></span>
                            </div>
                            <div class="user-wrapper bg-dark">
                                <a class="user-link" href="">
                                    <img class="media-object img-thumbnail user-img" alt="User Picture" src="assets/img/user.gif">
                                    <span class="label label-danger user-label">16</span>
                                </a>
                        
                                <div class="media-body">
                                    <h5 class="media-heading"><?php
                                     if(isset($_SESSION['fego_user']))
                                      {
                                        echo $_SESSION['fego_user'];
                                      }
                                        ?> 
                                      </h5>
                                    <ul class="list-unstyled user-info">
                                        <li><a href="">HR/Admin</a></li>
                                        <li>
                                            <?php $date = date('Y-m-d H:i:s'); echo "$date"; ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- #menu -->
                        <ul id="menu" class="bg-blue dker">
                                  <li class="nav-header">Menu</li>
                                  <li class="nav-divider"></li>
                                  <li class="">
                                    <a href="dashboardhr.php">
                                      <i class="fa fa-dashboard1"></i><span class="link-title">&nbsp;HR/Admin Dashboard</span>
                                    </a>
                                  </li>

                                  <li>
                                        <a href="data_capturing.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Register A guard</a>
                                      </li>
                                      <li>
                                      <a href="client_registration.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Client Registration</a>
                                      </li>
                                      <li>
                                      <a href="update_client.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Update Client</a>
                                      </li>
                                      
                                      <li>
                                      <a href="bank_records.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Update Bank Records</a>
                                      </li>
                                      <li>
                                      <a href="client_database.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Clients Database</a>
                                      </li>
                                      <li>
                                        <a href="id-card.html">
                                          <i class="fa fa-angle-right"></i>&nbsp; Photo Id Card</a>
                                      </li>
                                      
                                      <li>
                                        <a href="guards.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Norminal Row </a>
                                      </li>
                                      <!--li>
                                        <a href="#">
                                          <i class="fa fa-angle-right"></i>&nbsp; Delete Guard Record </a>
                                      </li-->
                                    <ul class="collapse">
                                      
                                    </ul>
                                  </li>
                                 
                                    </ul-->
                                  </li>
                                 
                                  <li>
                                    <a href="calendar.html">
                                      <i class="fa fa-calendar"></i>
                                      <span class="link-title">
                                    Calendar
                                  </span>
                                    </a>
                                  </li>
                                  
                                  <li class="nav-divider"></li>
                                  <li>
                                    <a href="../index.html">
                                      <i class="fa fa-sign-in"></i>
                                      <span class="link-title">
                            Logout
                            </span>
                                    </a>
                                  </li>
                                  
                                </ul>
                        <!-- /#menu -->
                    </div>
                    <!-- /#left -->
                <div id="content">
                    <div class="outer">
                        <div class="inner bg-light lter">
                            <!--BEGIN INPUT TEXT FIELDS-->
<div class="row">
<div class="col-lg-12">
    <div class="box success">
        <header>
            <div class="icons"><i class="fa fa-edit"></i></div>
            <h5>Edit client</h5>
            <!-- .toolbar -->
            <div class="toolbar">
              <nav style="padding: 8px;">
                  <a href="javascript:;" class="btn btn-default btn-xs collapse-box">
                      <i class="fa fa-minus"></i>
                  </a>
                  <a href="javascript:;" class="btn btn-default btn-xs full-box">
                      <i class="fa fa-expand"></i>
                  </a>
                  <a href="javascript:;" class="btn btn-danger btn-xs close-box">
                      <i class="fa fa-times"></i>
                  </a>
              </nav>
            </div>            <!-- /.toolbar -->
        </header>
        <div id="div-1" class="body">
            <!--form class="form-horizontal" action="update_client.php" method="post">

                    <?php
  
  if(isset($_SESSION["creation-successful"]))
  {

    echo "<p class='center-block'>" . $_SESSION["creation-successful"] . "</p>";
    unset($_SESSION["creation-successful"]);

  }

?> 

                   <div class="form-group">
                    <label for="text1" class="control-label col-lg-4">Name of client</label>

                    <div class="col-lg-4">
                         <?php 

                                $query = "SELECT * FROM alpha_client";
                                if($result = mysqli_query($db, $query))
                              {

                                
                              if ($result->num_rows > 0){


                               echo '<select name="clients_name">'; // Open your drop down box
                                      

                              // Loop through the query results, outputing the options one by one
                              while($row = $result->fetch_assoc()) {
                                 echo '<option value="'.$row['clients_name'].'">'.$row['clients_name'].'</option>';
                              }

                              echo '</select>'; 
                            }

                          }
                            ?>
                    </div>
                </div>

                <div class="form-actions no-margin-bottom" style="padding-right: 50px;">
                        <input type="submit" value="Update" class="btn btn-success">
                    </div>

              </form>

              <hr-->

              <form class="form-horizontal" action="client_update_process.php" method="post">

                 <?php 
                 if(!empty($_POST))

                 $client_id = $_POST['client_id'];

                                $query = "SELECT * FROM alpha_client WHERE id = $client_id";
                                if($result = mysqli_query($db, $query))
                                {
                                  while($row = mysqli_fetch_assoc($result) ) {
                          ?>
                                <div class="form-group">
                    <label for="text1" class="control-label col-lg-4">Name of client</label>

                    <div class="col-lg-4">
                        <input type="text" id="text1" required name="clients_name" value="<?php echo $row ['clients_name']; ?>" class="form-control">
                    </div>
                </div>

                                <div class="form-group"> 
                    <label for="text1" class="control-label col-lg-4">Office Address</label>

                    <div class="col-lg-4">
                       
                        <input type="text" id="text1" required name="clients_office"  value="<?php echo $row ['clients_office_address']; ?>" class="form-control"> 
                    </div>

                </div>
                 <div class="form-group">
                    <label for="text1" class="control-label col-lg-4">Official Phone Number</label>

                    <div class="col-lg-4">
                        <input type="text" id="text1"  name="official_phone_number" value="<?php echo $row ['official_phone_number']; ?>" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="text1" class="control-label col-lg-4">Email Address</label>

                    <div class="col-lg-4">
                        <input type="email" id="text1" required name="clients_email" value="<?php echo $row ['clients_email']; ?>" class="form-control">
                    </div>
                </div>

                <?php
                       }

                         }
                      ?>

                <hr>

                <?php

                 
                $client_id = $_POST['client_id'];

                                $query = "SELECT * FROM alpha_client_contacts WHERE client_id = $client_id";
                                if($result = mysqli_query($db, $query))
                                {

                                while($row = $result->fetch_assoc())
                                
                                {

                                ?> 
                 <template id="contact-template">                
  <div class="form-group">
    <label for="text1" class="control-label col-lg-4">Contact person</label>

    <div class="col-lg-4">
        <input type="text" id="text1"  name="contact_person_name[]" value="<?php echo $row ['contact_person_name']; ?>" class="form-control">
    </div>
  </div>

  <div class="form-group">
    <label for="text2" class="control-label col-lg-4">Contact Person Phone Number</label>

    <div class="col-lg-4">
      <div class="input-group">
        <input class="form-control"   name="contact_person_phone_number[]" type="text" value="<?php echo $row['contact_person_phone_number']; ?> ">
      </div>
    </div>
  </div>           
  <div class="form-group">
    <label for="text1" class="control-label col-lg-4">Email Address</label>

    <div class="col-lg-4" style="margin-bottom: 35px;">
        <input type="email" id="text1" required name="contact_email[]" placeholder="e.g contactperson@domain.com"  value="<?php echo $row['contact_email']; ?> " class="form-control">
    </div>
  </div>
</template>
                <div id="contact-area">
                  
                </div>
                <script type="text/javascript">
                  $(document).ready( function(){
                    const contactTemplate = $('#contact-template').html();
                    const contactArea = $('#contact-area');
                    const addContactBtn = $('#add-more-contact-btn');
                    const locationTemplate = $('#location_template').html();
                    const locationArea = $('#location_area');
                    const addLocationBtn = $('#add_location_button');

                    
                              
                     
                    function appendContact(){
                      contactArea.append(contactTemplate)
                    }
                     function appendLocation(){
                      locationArea.append(locationTemplate)
                      console.log('appended location');
                     }

                    addContactBtn.on('click', appendContact)
                    addLocationBtn.on('click', appendLocation)

                    locationArea.on('change','.require_supervisor' , function(e){
                      const value = $(this).val() 
                      const self = this;
                      const supervisorDetails = $(e.target.parentElement.parentElement.nextElementSibling)
                      console.log(supervisorDetails)
                      if(value.toLowerCase() == 'yes') {
                        supervisorDetails.show(300)
                        return;
                      }
                        supervisorDetails.hide(300)
                    })
                    // Kick things off by appending a contact and location, comment out to disable
                    appendContact()
                    appendLocation()


                  });
                </script>
                <!--add more contact button-->
                <?php

                
                                }
                              }

                                ?>



                 <div class="form-actions no-margin-bottom" style="padding-left: 350px;">
                        <input type="button" value="Add More Contact" id="add-more-contact-btn" class="btn btn-sm btn-warning">
                    </div>
                    <br>
                <hr>

                
                 


                    
                     <?php

                $client_id = $_POST['client_id'];

                                $query = "SELECT * FROM beat WHERE client_id = $client_id";
                                if($result = mysqli_query($db, $query))

                                while($row = $result->fetch_assoc())
                                
                                {

                                ?>                                

                <template id="location_template">
                  <div class="form-group">
                    <label for="text1" class="control-label col-lg-4">Name of beat/Location</label>
                    <div class="col-lg-4">
                          <input type="text" id="text1"  name="beat_name[]" value="<!-- <?php echo $row ['beat_name']; ?> -->" placeholder="name of beat/location" class="form-control">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="text1" class="control-label col-lg-4">Address</label>
                    <div class="col-lg-4">
                        <input type="text id="text4"  name="beat_address[]" value="<?php echo $row ['beat_address']; ?>"class="form-control">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="text1" class="control-label col-lg-4" >Number of Guards</label>
                    <div class="col-lg-4">
                      <input type="number" id="tet4" required name="beat_no_of_guards[]" value="<?php echo $row ['number_of_guards']; ?>" class="form-control number_of_guards">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-lg-4">Amount Per Guard</label>
                    <div class="col-lg-4">
                      <input type="number" id="text1" required name="beat_amount_per_guard[]" value="<?php echo $row ['cost_per_guard']; ?>" placeholder="N10,000" class="form-control">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-lg-4">Requires Supervisors?</label>
                    <div class="col-lg-4">
                      <input class="check_btn require_supervisor" type="radio" name="requires_supervisor" required value="Yes">Yes
                      <input type="radio" class=" require_supervisor"  name="requires_supervisor"required  value="No">No
                      <br>
                    </div>
                  </div>
                  <div class="supervisor-details" style="display: none;">
                    <div class="form-group">
                      <label class="control-label col-lg-4">Number of supervisor</label>

                      <div class="col-lg-4">
                          <input type="number" name="beat_number_of_supervisor[]" value="<?php echo $row ['number_of_supervisor']; ?>" class="form-control number_of_supervisor">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-lg-4">Amount per supervisor</label>

                      <div class="col-lg-4">
                          <input type="number" id="text1"  name="beat_amount_per_supervisor[]" value="<?php echo $row ['cost_per_supervisor']; ?>"  placeholder=" Amount per supervisor" class="form-control">
                          
                    </div>
                  </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-lg-4">Date of Deployment</label>
                    <div class="col-lg-4">
                      <input class="form-control" type="date" value="<?php echo $row ['date_of_deployment']; ?>" name="beat_date_of_deployment[]" required>
                    </div>
                  </div> 
                <hr>  

                  </template>
                  <script type="text/javascript">
                    $(document).ready(function(){
                      const $numberOfSupervisorInputs = $('.number_of_supervisor');
                      const $locationArea = $('#location_area');
                      const locationArea = document.querySelector('#location_area');
                      const totalNumberOfSupervisorsField = document.querySelector('#number_of_supervisor');
                      const totalNumberOfGuardsField = document.querySelector('#number_of_guards');

                      function gettotalGuards(){

                          const numberOfGuardsInputs = Array.from(document.querySelectorAll('.number_of_guards'));
                          const total = numberOfGuardsInputs.reduce(function(carry, input, i){
                            return parseInt(carry) + parseInt(input.value);
                          },0)
                          totalNumberOfGuardsField.value = total;
                      }

                        function gettotalSupervisors(){
                          const numberOfSupervisorsInputs = Array.from(locationArea.querySelectorAll('.number_of_supervisor'));
                          const total = numberOfSupervisorsInputs.reduce(function(carry, input, i){
                            return parseInt(carry) + parseInt(input.value);
                          },0)
                          totalNumberOfSupervisorsField.value = total;
                      }

                      $locationArea.on('input', '.number_of_guards', function(){
                          gettotalGuards();
                      })

                      $locationArea.on('input', '.number_of_supervisor', function(){
                        console.log('get total supervisor')
                        gettotalSupervisors()
                      })

                    })
                  </script>
                  <div id="location_area">
                    
                  </div>
                 <!--add more contact button-->

                 <!--add more contact button-->

                   <?php
                         }
                      ?>

                 <div class="form-actions no-margin-bottom" style="padding-left: 350px;">
                        <input id="add_location_button" type="button" value="Add More Beat" class="btn btn-sm btn-warning">
                    </div>
                    <br>

                  

                <!-- closes-->
                
                
                
                <div class="form-actions no-margin-bottom" style="padding-right: 50px;">
                        <input type="submit" value="Update" class="btn btn-success">
                    </div>
            </form>
        </div>
    </div>
</div>

                        <div class="modal-footer">
                            <!--button type="button" class="btn btn-default" data-dismiss="modal">Close</button-->
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
            <!-- /.modal -->
            <!-- /#helpModal -->
            <!--jQuery -->
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.14.1/moment.min.js"></script>
                    <script src="//cdnjs.cloudflare.com/ajax/libs/Uniform.js/2.1.2/jquery.uniform.min.js"></script>
                    <script src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.1.0/chosen.jquery.min.js"></script>
                    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-tagsinput/1.3.3/jquery.tagsinput.min.js"></script>
                    <script src="//cdnjs.cloudflare.com/ajax/libs/autosize.js/1.18.17/jquery.autosize.min.js"></script>
                    <script src="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/js/jasny-bootstrap.min.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.2/js/bootstrap-switch.min.js"></script>
                    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.1/js/bootstrap-datepicker.min.js"></script>
                    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.0.1/js/bootstrap-colorpicker.min.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

            <!--Bootstrap -->
            <script src="assets/lib/bootstrap/js/bootstrap.js"></script>
            <!-- MetisMenu -->
            <script src="assets/lib/metismenu/metisMenu.js"></script>
            <!-- onoffcanvas -->
            <script src="assets/lib/onoffcanvas/onoffcanvas.js"></script>
            <!-- Screenfull -->
            <script src="assets/lib/screenfull/screenfull.js"></script>

                    <script src="/assets/lib/inputlimiter/jquery.inputlimiter.js"></script>
                    <script src="/assets/lib/validVal/js/jquery.validVal.min.js"></script>
                    <script src="/assets/lib/bootstrap-daterangepicker/daterangepicker.js"></script>

            <!-- Metis core scripts -->
            <script src="assets/js/core.js"></script>
            <!-- Metis demo scripts -->
            <script src="assets/js/app.js"></script>

                <script>
                    $(function() {
                      Metis.formGeneral();
                    });
                </script>

            <script src="assets/js/style-switcher.js"></script>
        </body>

</html>
