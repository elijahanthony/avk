<?php
	
	session_start();


	if(isset($_POST))
	{

	   require 'incfile.php';
    

		$fname = $_POST['fname'];
		$d_o_b = $_POST['d_o_b'];
		$state = $_POST['state'];
		$religion = $_POST['religion'];
		$address = $_POST['address'];
		$qualification = $_POST['qualification'];
		$d_o_e = $_POST['d_o_e'];
		

		
		
			$query = " UPDATE romeo_guards SET d_o_b = '$d_o_b', state = '$state', religion = '$religion',  qualification = '$qualification', application_date = '$d_o_e'
			WHERE
			f_name = '$fname'";

		if ($result = mysqli_query($db, $query))
        {

        	if (mysqli_affected_rows($db) == 1) 
        	{
        		
        		$_SESSION["creation-successful"] = "<h6>A new applicant, $fname has <br>been successfully documented.</h6>
        		<h6>fill the form below to complete <br>
        		applicant biometric<h6>";
	            header('Location:biometric.php');
				exit();

        	}
        	else {
        		echo "Guard has not been verified. <br> Go back and start the process again";
        	}


        	
        }

		

		

	}

?>