<?php
session_start();

if (isset($_POST)) {
   
    require 'incfile.php';


      $pic = $_POST['pic'];
      $fname = $_POST['fname'];
      
      $query = " UPDATE romeo_guards SET passport = '$pic' WHERE f_name = '$fname'";

    if ($result = mysqli_query($db, $query))
        {

          if (mysqli_affected_rows($db) == 1) 
          {
            
            $_SESSION["creation-successful"] = "<h6>The new application is successful<br> The Applicant Status is still in PENDING.</h6>
            <h6>if he meets the company requirement <br>
            <hr>
            visit the POST A GUARD page to post him <h6>";
              header('Location:biometric.php');
        exit();

          }

          else {
            echo "applicant is not verified not already exist. <br> Go back and start the process again";
          }


          
        }
       } 

?>