<?php
	
	session_start(); // Carbon::today()->subtractMonths(3)->toTimeString();
	

	if(!empty($_POST))
{
	require 'incfile.php';


		$full_name = $_POST['full_name'];
		$date_given = date('Y-m-d');
		$month = date("F",strtotime("0 month"));
		//$date_paid = $_POST['date_paid'];
		$amount = $_POST['amount'];
		$advance = 'salary';

		$full_name_id = $_SESSION['$full_name_id'];
		//$description = $_POST['description'];

		// $phone_number = $_POST['phone_number'];
		// $address = $_POST['address'];

		// RUN INSERT TO ALPHA CLIENT HERE


		// $query = "INSERT INTO alpha_guards (advance) VALUES('$advance') WHERE full_name = $full_name_id";
		// if ($result = mysqli_query($db, $query)) {
		// 	$full_name_id =  mysqli_insert_id($db);

		// }


		

		$query = "INSERT INTO advance_salary (full_name, date_given, month, amount, full_name_id) VALUES('$full_name','$date_given', '$month', '$amount', '$full_name_id')";

		if ($result = mysqli_query($db, $query))
        {

        	if (mysqli_affected_rows($db) == 1) 
        	{
        		
        		$_SESSION["creation-successful"] = "<h6>$full_name Just Got Salary Advacnce <br> to be deducted in the next salary .</h6>";
	            header('Location:salary_advance.php');
				exit();

        	}

        	
        }

	}

?>