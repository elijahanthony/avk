<?php
	
	session_start();


	if(isset($_POST))
	{

		
    require 'incfile.php';
    


		$fname = $_POST['fname'];
		$height = $_POST['height'];
		$sign_up_refer = $_POST['sign_up_refer'];
		$referral_name = $_POST['referral_name'];
		$referral_address = $_POST['referral_address'];
		$referral_phone = $_POST['referral_phone'];
		$sign_up_read = $_POST['sign_up_read'];
		$sign_up_write = $_POST['sign_up_write'];
		$sign_up_verified = $_POST['sign_up_verified'];

		//if

		//if($sign_up_retype_password != $sign_up_password )
		//{

			//$_SESSION['password_error'] = "Passwords do not match!";
			//header("Location: registration1.php");
			//exit();

		//}


		$query = "INSERT INTO romeo_guards(f_name, height, who_refer, referrer_name, referrer_address, phone_number, h_read, h_write, verified) VALUES('$fname', '$height', '$sign_up_refer', '$referral_name', '$referral_address', '$referral_phone', '$sign_up_read', '$sign_up_write', '$sign_up_verified')";
		if ($result = mysqli_query($db, $query))
        {

        	if (mysqli_affected_rows($db) == 1) 
        	{
        		
        		$_SESSION["creation-successful"] = "<h6>A new applicant has <br>been successfully verified.</h6>
        		<h6>fill the form below to complete <br>
        		applicant documentation<h6>";
	            header('Location:applicant_form.php');
				exit();

        	}

        	
        }

	}

?>