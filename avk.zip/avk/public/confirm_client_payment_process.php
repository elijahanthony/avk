<?php
session_start();


    require 'incfile.php';
    
 if(!empty($_POST))
{
//$date = ; 
$client = $_POST['client'];
$date_start = $_POST['date_start'];
$date_end = $_POST['date_end'];
$date_of_payment = date('Y-m-d');


//$query = "SELECT id, client_id  FROM alpha_client INNER JOIN client_invoice on id = client_id;"

$query = "UPDATE client_invoice SET date_start = '$date_start', date_end = '$date_end', date_of_payment = '$date_of_payment' 
WHERE clients_name = '$client'";


		if($result = mysqli_query($db, $query)){
				if (mysqli_affected_rows($db) == 1) {
			$_SESSION["creation-successful"] = "<h6> payment confirmed<h6>";
	            header('Location:confirm_client_payment.php');
				exit();	
		 	}
		 	else {
		 		echo "$client does not exist";
		 	}
	# code...

		}

 //if ($result->num_rows > 0)
}
		



?>