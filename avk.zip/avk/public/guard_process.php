<?php
	
	session_start(); // Carbon::today()->subtractMonths(3)->toTimeString();
	

	// if(!empty($_POST))
	if(isset($_SESSION))
{
	require 'incfile.php';



//
 					$full_name = $_SESSION['full_name'];
         		 	$fname = $_SESSION['fname'];
         	 		$lname = $_SESSION['lname'];
             		$other_name = $_SESSION['other_name'];
          	 		$height = $_SESSION['height'];

               		$who_refer  = $_SESSION['who_refer'];
                	$referrer_name = $_SESSION['referrer_name'];
                	$referrer_address = $_SESSION['referrer_address'];
                	$referrer_phone = $_SESSION['referrer_phone'];
                     
                 	$next_of_kin = $_SESSION['next_of_kin'];
                  	$relationship = $_SESSION['relationship'];
                    $nok_phone_number = $_SESSION['nok_phone_number'];
                  	// $contact_name = $_SESSION['contact_name'];
                   //  $contact_phone_number = $_SESSION['contact_phone_number'];
                   //  $contact_address = $_SESSION['contact_address'];
                    $vetting_details = $_SESSION['vetting_details'];

                    $guard_address = $_SESSION['guard_address'];
                   	$date_of_birth = $_SESSION['date_of_birth'];
                    $state_of_origin = $_SESSION['state_of_origin'];
                   	$qualification = $_SESSION['qualification'];
           			$title = $_SESSION['title'];
              		$religion = $_SESSION['religion'];
                    $guarantor_full_name = $_SESSION['guarantor_full_name'];
                    $nick_name = $_SESSION ['nick_name'];
                    $title = $_SESSION['title'];
                    $guarantor_fname = $_SESSION['guarantor_fname'];
                    $guarantor_lname = $_SESSION['guarantor_lname'];
                         // $guarantor_full_name =  $guarantor_full_name = $_POST['title'] . ' ' . $_POST['guarantor_fname'] .' ' . $_POST['guarantor_lname'];
                    $religion = $_SESSION['religion'];
                    $guarantor_email = $_SESSION['guarantor_email'];
                    $guarantor_gender = $_SESSION['guarantor_gender'];
                    $guarantor_phone_number = $_SESSION['guarantor_phone_number'];
                    $company_name = $_SESSION['company_name'];
                      //$business_name = $_SESSION['business_name'];
                    $guarantor_address = $_SESSION['guarantor_address'];
                    $guarantor_passport = $_SESSION['guarantor_passport'];
                    $guard_passport = $_SESSION['guard_passport'];
                    $years_of_relationship = $_SESSION['years_of_relationship'];
                    $rank = $_SESSION['rank'];
                    //$contact_person = $_SESSION['contact_person'];

                    $bank_name = $_SESSION['bank_name'];
                   	$account_name = $_SESSION['full_name'];
                    $account_number = $_SESSION['account_number'];



               //      $date_of_deployment = date('Y-m-d');
               //      $observation_days =   date('Y-m-d', strtotime(' + 3 days'));
             		// $salary = $_SESSION['salary'];
               // 		$position = $_SESSION['position'];
               //  	$beat_name = $_SESSION['beat_name'];












                    $query = "SELECT * FROM alpha_guards WHERE  full_name = '$full_name' LIMIT 1";
        if ($result = mysqli_query($db, $query)) {
            if (mysqli_affected_rows($db) == 1) {

                echo "<div style= ><p>This guard already exist</p><br>
                <a href='data_capturing.php'></a>Please go back</div>";
                //header('Location:client_registration.php');
                exit();
                $_SESSION["creation-successful"] = "<h2> This guard already exist!<br> Only Register a new guard.</h2>";
            header('Location:data_capturing.php');
            exit(); 
                
            }
            
        }

		$query = "INSERT INTO alpha_guards (full_name, first_name, last_name, height, date_of_birth, state_of_origin, religion, house_address, qualification, guard_passport ) VALUES ('$full_name', '$fname', '$lname', '$height', '$date_of_birth', '$state_of_origin', '$religion', '$guard_address', '$qualification', '$guard_passport')";
        // if (!mysqli_query($db, $query)){
        //     echo 'Failed to connect at all';
        //     die();
       // }
		if (mysqli_query($db, $query)) {
			$_SESSION['$full_name_id'] = $full_name_id= mysqli_insert_id($db);
		}

		$query = "INSERT INTO referrer (full_name, full_name_id, type_of_referrer, referrer_name, referrer_address, referrer_phone_number) VALUES ('$full_name', '$full_name_id', '$who_refer', '$referrer_name', '$referrer_address', '$referrer_phone')";
		if (mysqli_query($db, $query)) {
			//$full_nameid =  mysqli_insert_id($db);
		}


		$query = "INSERT INTO next_of_kin (full_name, full_name_id, name_next_of_kin, relationship, nok_phone_number) VALUES ('$full_name', '$full_name_id', '$next_of_kin', '$relationship', '$nok_phone_number')";
		if (mysqli_query($db, $query)) {
			//$full_nameid =  mysqli_insert_id($db);
		}

		$query = "INSERT INTO guarantor (full_name, full_name_id, guarantor_full_name, guarantor_phone_number, company_address, company_name, guarantor_address, years_of_relationship, guarantor_email, guarantor_gender, guarantor_fname, guarantor_lname, guarantor_passport, rank) VALUES ('$full_name', '$full_name_id', '$guarantor_full_name', '$guarantor_phone_number', 'company_address', '$company_name', '$guarantor_address', '$years_of_relationship', '$guarantor_email', '$guarantor_gender', '$guarantor_fname', '$guarantor_lname', '$guarantor_passport', '$rank')";
		if (mysqli_query($db, $query)) {
			//$full_nameid =  mysqli_insert_id($db);
		}



            $contact_query = "INSERT INTO vetting (nick_name, vetting_details, full_name_id, full_name) VALUES ('$nick_name', '$vetting_details', '$full_name_id', '$full_name')";
        
        }
		// $contact_query = "INSERT INTO vetting (nick_name, full_name_id, full_name) VALUES";
		// for($i = 0; $i < count($_SESSION['contact_name']); $i++){
		// 	$contact_query .= "('{$_SESSION['contact_name'][$i]}', '{$_SESSION['contact_phone_number'][$i]}', '{$_SESSION['contact_address'][$i]}', $full_name_id, '$full_name')";
		// 	$contact_query .= $i == ( count($_SESSION['contact_name']) - 1) ? '' : ',';
		// }

        if (!mysqli_query($db, $contact_query)){
        	echo 'the vetting details are too much';
        	die();
        }

        $query = "INSERT INTO  bank (full_name, full_name_id, bank_name, account_number, account_name) VALUES ('$full_name', '$full_name_id', '$bank_name', '$account_number', '$full_name')";
		if (mysqli_query($db, $query)) {
			//$full_nameid =  mysqli_insert_id($db);
		}

        

		// $query = "INSERT INTO deployment (full_name, full_name_id, date_of_deployment, observation_end, beat, salary, position) VALUES ('$full_name', '$full_name_id', '$date_of_deployment', 'observation_end', '$beat_name', 'salary', '$position')";


		
        if (mysqli_query($db, $query)){
        	
        	$_SESSION["creation-successful"] = "<h6> CONGRATULATIONS! <br><b> $full_name 's </b><br> Application was successful.</h6>";
            header('Location:data_capturing.php');
			exit();	
			
		}


    
		

   

?>