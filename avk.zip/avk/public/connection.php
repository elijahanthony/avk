<?php

  session_start();


  if(isset($_POST))
  {

   require 'incfile.php';


    $sign_in_username = $_POST['sign_in_username'];
    $sign_in_password = md5($_POST['sign_in_password']);


    // $query = "SELECT * FROM umbrella_users WHERE username='$sign_in_username' AND password='$sign_in_password'";
    // if($result = mysqli_query($db, $query))
    //   {
        
    //     if(mysqli_num_rows($result) == 1)
    //     {

    //       $_SESSION['fego_user'] = $sign_in_username;
    //       header("Location:dashboard1.php");
    //       exit();

    //     }
        
    //   }
        $department = "hr/admin";
        
          $query = "SELECT department FROM umbrella_users WHERE username = '$sign_in_username' AND password = '$sign_in_password' AND department = 'admin' ";
          if ($result = mysqli_query($db, $query)) {
            
            if (mysqli_affected_rows($db) == 1) {
            $_SESSION['fego_user'] = $sign_in_username;
            header("Location:dashboard1.php");
            echo("Welcome $sign_in_username");
          exit();

          }

          elseif (mysqli_affected_rows($db) == 0) {
              $query = "SELECT department FROM umbrella_users WHERE username = '$sign_in_username' AND password = '$sign_in_password' AND department = 'hr/admin' ";
          if ($result = mysqli_query($db, $query)) {
            
            if (mysqli_affected_rows($db) == 1) {
            $_SESSION['fego_user'] = $sign_in_username;
            header("Location:dashboardhr.php");
            echo("Welcome $sign_in_username");
          exit();

          }

          }
            # code...
          }
          }

         

           $query = "SELECT department FROM umbrella_users WHERE username = '$sign_in_username' AND password = '$sign_in_password' AND department = 'operations' ";
          if ($result = mysqli_query($db, $query)) {
            
            if (mysqli_affected_rows($db) == 1) {
            $_SESSION['fego_user'] = $sign_in_username;
            header("Location:dashboardoperations.php");
            echo("Welcome $sign_in_username");
          exit();

          }

          }

           $query = "SELECT department FROM umbrella_users WHERE username = '$sign_in_username' AND password = '$sign_in_password' AND department = 'accounting' ";
          if ($result = mysqli_query($db, $query)) {
            
            if (mysqli_affected_rows($db) == 1) {
            $_SESSION['fego_user'] = $sign_in_username;
            header("Location:dashboardaccounting.php");
            echo("Welcome $sign_in_username");
          exit();

          }

          }
          # code...
        //elseif(mysqli_num_rows($result) == 0)
     
  }
        
        

      


      
?>
