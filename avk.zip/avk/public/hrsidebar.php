<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 <ul id="menu" class="bg-blue dker">
                                  <li class="nav-header">Menu</li>
                                  <li class="nav-divider"></li>
                                  <li class="">
                                    <a href="dashboardhr.php">
                                      <i class="fa fa-dashboard1"></i><span class="link-title">&nbsp;HR/Admin Dashboard</span>
                                    </a>
                                  </li>

                                  <li>
                                        <a href="data_capturing.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Register A guard</a>
                                      </li>
                                      <li>
                                        <li>
                                        <a href="deploy_guard.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Deploy A guard</a>
                                      </li>
                                      <li>
                                      <a href="client_registration.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Client Registration</a>
                                      </li>
                                      <li>
                                      <a href="update_client.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Update Client</a>
                                      </li>
                                      
                                      <li>
                                      <a href="update_bank.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Update Bank Records</a>
                                      </li>
                                      <li>
                                      <a href="client_database.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Clients Database</a>
                                      </li>
                                      <li>
                                        <a href="id-card.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Photo Id Card</a>
                                      </li>
                                      
                                      <li>
                                        <a href="guards.php">
                                          <i class="fa fa-angle-right"></i>&nbsp; Norminal Row </a>
                                      </li>
                                      <!--li>
                                        <a href="#">
                                          <i class="fa fa-angle-right"></i>&nbsp; Delete Guard Record </a>
                                      </li-->
                                    <ul class="collapse">
                                      
                                    </ul>
                                  </li>
                                 
                                    </ul-->
                                  </li>
                                 
                                                                    
                                  <li class="nav-divider"></li>
                                  <li>
                                    <a href="../index.html">
                                      <i class="fa fa-sign-in"></i>
                                      <span class="link-title">
                            Logout
                            </span>
                                    </a>
                                  </li>
                                  
                                </ul>
</body>
</html>