<?php

session_start();

if (isset($_POST))
 {

    require 'incfile.php';
    
		  	$full_name = $_POST['full_name'];
		  	$deploy = $_POST["deploy"];
		  	//$g_name = $_POST["g_name"];
		  	$beat_name = $_POST["beat_name"];
		  	$beat_name2 = $_POST["beat_name2"];
		  	//$guarantor_phone_number = $_POST["guarantor_phone_number"];
		  	$position = $_POST["position"];
		  	$salary = $_POST["salary"];
		  	$month = date("F",strtotime("0 month"));
		  	$date_of_deployment = date('Y-m-d');
		  	$observation_ends = date('Y-m-d', strtotime(' + 3 days'));
		  	$reason = $_POST["reason"];
		  	$full_name_id = $_SESSION['$full_name_id'];



		 $query = " INSERT INTO deployment (full_name_id, full_name, beat, beat_posted_from, position, salary, month, date_of_deployment, observation_end, reason_posting, deploy) VALUES ('$full_name_id', '$full_name', '$beat_name', '$beat_name2', '$position', '$salary', '$month', '$date_of_deployment', '$observation_ends', '$reason', '$deploy')";

		 if($result = mysqli_query($db, $query))
		 {
		 	if(mysqli_affected_rows($db) == 1){
		 	$_SESSION["creation-successful"] = "<h2>$full_name has <br>been successfully posted to $beat_name2 </h2>";
	            header('Location:deploy_guard.php');
				exit();	
		 	}
		 
		 }

	
}
?>
