<?php
	
	session_start();


	if(isset($_POST))
	{

		
    require 'incfile.php';
    
		$full_name = $_POST['full_name'];
		$beat = $_POST['beat'];
		//$sign_up_username = $_POST['sign_up_username'];
		//$sign_up_email = $_POST['sign_up_email'];
		//$sign_up_phone = $_POST['sign_up_phone'];
		//$sign_up_department = $_POST['sign_up_department'];
		//$sign_up_password = md5($_POST['sign_up_password']);
		//$sign_up_retype_password = md5($_POST['sign_up_retype_password']);

		//if

		//if($sign_up_retype_password != $sign_up_password )
		//{

			//$_SESSION['password_error'] = "Passwords do not match!";
			//header("Location: registration1.php");
			//exit();

		//}


		$query = "INSERT INTO romeo_guards(f_name, beat) VALUES('$full_name', '$beat')";
		if ($result = mysqli_query($db, $query))
        {

        	if (mysqli_affected_rows($db) == 1) 
        	{
        		
        		$_SESSION["creation-successful"] = "A new guard has been successfully created.";
	            header('Location:guards.php');
				exit();

        	}

        }

	}

?>