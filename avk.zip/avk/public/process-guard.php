<?php 
session_start();
    //die(var_dump($_SESSION));

if(isset($_SESSION))
	{

    require 'incfile.php';
    
  

     // $_SESSION['full_name'] =  $full_name = $_POST['fname'] . ' ' . $_POST['lname'] .' ' . $_POST['other_name'];
     //               $_SESSION['fname'] =  $fname = $_POST['fname'];
     //               $_SESSION['lname'] =  $lname = $_POST['lname'];
     //               $_SESSION['other_name'] =  $other_name = $_POST['other_name'];
     //               $_SESSION['height']  = $height = $_POST['height'];

     //                  $_SESSION['who_refer'] = $who_refer  = $_POST['who_refer'];
     //                  $_SESSION['referrer_name'] = $referrer_name = $_POST['referrer_name'];
     //                  $_SESSION['referrer_address'] = $referrer_address = $_POST['referrer_address'];
     //                  $_SESSION['referrer_phone'] = $referrer_phone = $_POST['referrer_phone'];
     //                  $_SESSION['how_to_read'] = $how_to_read = $_POST['how_to_read'];
     //                  $_SESSION['how_to_write'] = $how_to_write = $_POST['how_to_write'];
     //                  $_SESSION['application_form_pay'] = $application_form_pay = $_POST['application_form_pay'];
     //                  $_SESSION['applicant_verified'] = $applicant_verified = $_POST['applicant_verified'];
     //                  $_SESSION['next_of_kin'] = $next_of_kin = $_POST['next_of_kin'];
     //                  $_SESSION['relationship'] = $relationship = $_POST['relationship'];
     //                  $_SESSION['nok_phone_number'] = $nok_phone_number = $_POST['nok_phone_number'];
     //                  $_SESSION['contact_name'] = $contact_name = $_POST['contact_name'];
     //                  $_SESSION['contact_phone_number'] = $contact_phone_number = $_POST['contact_phone_number'];
     //                  $_SESSION['contact_address'] = $contact_address = $_POST['contact_address'];
     //                  $_SESSION['guard_address'] = $guard_address = $_POST['guard_address'];
     //                  $_SESSION['date_of_birth'] = $date_of_birth = $_POST['date_of_birth'];
     //                  $_SESSION['state_of_origin'] = $state_of_origin = $_POST['state_of_origin'];
     //                  $_SESSION['qualification'] = $qualification = $_POST['qualification'];
     //                  $_SESSION['title'] = $title = $_POST['title'];
     //                  $_SESSION['religion'] = $religion = $_POST['religion'];
     //                  $_SESSION['guarantor_name'] = $guarantor_name = $_POST['guarantor_name'];
     //                  $_SESSION['guarantor_phone_number'] = $guarantor_phone_number = $_POST['guarantor_phone_number'];
     //                  $_SESSION['company_name'] = $company_name = $_POST['company_name'];
     //                  $_SESSION['business_name'] = $business_name = $_POST['business_name'];
     //                  $_SESSION['guarantor_passport'] = $guarantor_passport = $_POST['guarantor_passport'];
     //                  $_SESSION['guard_passport'] = $_POST['guard_passport'];
     //                   $_SESSION['bank_name'] = $bank_name = $_POST['bank_name'];
     //                   $_SESSION['account_name'] = $account_name = $_POST['account_name'];
     //                   $_SESSION['account_number'] = $account_number = $_POST['account_number'];
     //                   $_SESSION['date_of_deployment'] = $date_of_deployment = $_POST['date_of_deployment']
     //                   $_SESSION['observation_days'] = $observation_days = $_POST['observation_days'];
     //                   $_SESSION['salary'] = $salary = $_POST['salary'];
     //                   $_SESSION['position'] = $position = $_POST['position'];
     //                   $_SESSION['beat_name'] = $beat_name = $_POST['beat_name'];

                    $full_name = $_SESSION['full_name'];
                    $fname = $_SESSION['fname'];
                    $lname = $_SESSION['lname'];
                    $other_name =  $_SESSION['other_name'];
                    $height = $_SESSION['height'];
                    $who_refer = $_SESSION['who_refer'];
                    $referrer_name = $_SESSION['referrer_name'];
                    $referrer_address = $_SESSION['referrer_address'];
                    $referrer_phone =  $_SESSION['referrer_phone'];
                    $vetting_details = $_SESSION['vetting_details'];
                     
                      $next_of_kin = $_SESSION['next_of_kin'];
                      $relationship = $_SESSION['relationship'];
                      $nok_phone_number = $_SESSION['nok_phone_number'];
                     //  $contact_name = $_SESSION['contact_name'];
                     //  $contact_phone_number = $_SESSION['contact_phone_number'];
                     // $contact_address = $_SESSION['contact_address'];
                      $guard_address = $_SESSION['guard_address'];
                      $date_of_birth = $_SESSION['date_of_birth'];
                      $state_of_origin = $_SESSION['state_of_origin'];
                      $qualification = $_SESSION['qualification'];
                     $title = $_SESSION['title'];
                      $religion = $_SESSION['religion'];
                     $guarantor_full_name = $_SESSION['guarantor_full_name'];
                      $nick_name = $_SESSION ['nick_name'];
                      $title = $_SESSION['title'];
                      $guarantor_fname = $_SESSION['guarantor_fname'];
                      $guarantor_lname = $_SESSION['guarantor_lname'];
                     // $guarantor_full_name =  $guarantor_full_name = $_POST['title'] . ' ' . $_POST['guarantor_fname'] .' ' . $_POST['guarantor_lname'];
                      $religion = $_SESSION['religion'];
                      $guarantor_email = $_SESSION['guarantor_email'];
                      $guarantor_gender = $_SESSION['guarantor_gender'];

                      $guarantor_phone_number = $_SESSION['guarantor_phone_number'];
                      $company_name = $_SESSION['company_name'];
                      //$business_name = $_SESSION['business_name'];
                      $guarantor_address = $_SESSION['guarantor_address'];
                      $guarantor_passport = $_SESSION['guarantor_passport'];
                      $guard_passport = $_SESSION['guard_passport'];
                      $years_of_relationship = $_SESSION['years_of_relationship'];
                       $rank = $_SESSION['rank'];
                       //$vetting_details = $_SESSION['vetting_details'];

                     //bank and deployment
                      //

                     $_SESSION['bank_name'] = $bank_name = $_POST['bank_name'];
                       $_SESSION['account_name'] = $account_name = $_POST['full_name'];
                       $_SESSION['account_number'] = $account_number = $_POST['account_number'];
                       // $_SESSION['date_of_deployment'] = $date_of_deployment = date('Y-m-d');
                       // $_SESSION['observation_ends'] = $observation_days =   date('Y-m-d', strtotime(' + 3 days'));
      
      echo " 
      <div style='margin-left:250px; margin-right:250px;'>
      <H4 style='text-align: center;'>AVK SECURIY SERVICES<br></H4>
      <H3 style='text-align: center; color: green;'>APPLICATION COMPLETE!</H3>
      <marquee><p> Properly check the Information below to avoid error!<p></marquee>

    <b>Applicant Full Name<b> - $full_name
    <hr>
    First Name - $fname
<hr>
    Last Name - $lname

    <hr>

    Other Name - $other_name
    <hr>

 	Height - $height
 	<hr>
    Who Refeer - $who_refer
    <hr>
    
       Name of referrer -  $referrer_name
       <hr>
 Referrer Address - $referrer_address
<hr>
   Referrer Phone Number $referrer_phone
<hr>
 


    Next oF Kin -   $next_of_kin
<hr>
     Relationship - $relationship
<hr>
   Next Of Kin Phone Number - $nok_phone_number

<hr>
   Guard's Address -  $guard_address
<hr>
      Date Of birth - $date_of_birth
<hr>
  State Of Origin - $state_of_origin
<hr>
    Qualification - $qualification
<hr>
            Religion - $religion 
<hr>

Nick Name - $nick_name
<hr>

Vetting Details - $vetting_details
<hr
          
     Guarantor Name - $guarantor_full_name
<hr>
Guarantor First Name - $guarantor_fname
<hr>
gurantor Last Name - $guarantor_lname 

<hr>

gurantor Email - $guarantor_email
<hr>

guarantor Gender - $guarantor_gender
<hr>
 Guarantor Phone Number - $guarantor_phone_number
<hr>


  Company -   $company_name 

<hr>
 Guanrantor Passport - $guarantor_passport
 <img id='image' style='width: 50%; height: 50;'>
    
<hr>
         Bank Name - $bank_name
<hr>
      Account Name - $full_name
<hr>
    Account Number - $account_number

        <hr>
        Guard Passport - $guard_passport
         <img id='image' style='width: 50%; height: 50;'>

    </div>"
    ;



        		// $_SESSION["creation-successful"] = "<h6>A new applicant has <br>been successfully verified.</h6>
        		// <h6>fill the form below to complete <br>
        		// applicant documentation<h6>";
	         //    header('Location:dashboardhr.php');
				//exit();

        	// }
    //     	else
    //     	 {
		 	//Date Of Deployment - $date_of_deployment
// <hr>
//   Observation Days ends - $observation_days
//   <hr>

//             Salary -$salary
// <hr>
//          Position - $position 
//          <hr> 
      //	echo " $fname already exist <br> Thank you";
		 		
		 		
				
		 	// }

        	
        }

    // }
    ?>


 <marquee><b style="color: blue;">Final stage for <?=$full_name?></b></marquee>
    <div>
<!--a href="guards_reg_process.php">Back</a-->
<a href="" style="margin-left: 50px;" onclick="myFunction()">Print</a>
<form action="<?php echo "guard_process.php?" .SID ?>" method="post"><div class='form-actions no-margin-bottom' style='margin-left: 900px;'>
                        <input type='submit' value='Submit' class='btn btn-primary'>
                    </div>
                </form>


                <a href="" style="margin-left: 50px;" onclick="backButton()">Back</a>
             
             <!--form action="bank_records.php" method="post"><div class='form-actions no-margin-bottom' style='margin-left: 900px;'>
                        <input type='submit' value='Update bank details' class='btn btn-primary'>
                    </div>
                </form-->

</div>
<script>
function myFunction() {
    window.print();
}

function backButton(){
  window.history.back();
}
</script>
