<?php
	
	session_start(); // Carbon::today()->subtractMonths(3)->toTimeString();
	

	if(!empty($_POST))
{
	require 'incfile.php';

		$clients_name = $_POST['clients_name'];
		$date_of_registration = date('Y-m-d');
		$official_phone_number = $_POST['official_phone_number'];
		$clients_office = $_POST['clients_office'];
		$clients_email = $_POST['clients_email'];
		$contact_person_name = $_POST['contact_person_name'];
		$contact_person_phone_number = $_POST['contact_person_phone_number'];
		$contact_email = $_POST['contact_email'];
		$requires_supervisor = $_POST['requires_supervisor'];
		$beat_name = $_POST['beat_name'];
		$beat_address = $_POST['beat_address'];
		$number_of_guards = $_POST['number_of_guards'];
		// $amount_per_guard = $_POST['amount_per_guard'];
		$number_of_supervisor = $_POST['number_of_supervisor'];
		// $amount_per_supervisor = $_POST['amount_per_supervisor'];

		$days = date("t");
	
		// RUN INSERT TO ALPHA CLIENT HERE
		$query = "SELECT * FROM alpha_client WHERE 	clients_name = '$clients_name' LIMIT 1";
		if ($result = mysqli_query($db, $query)) {
			if (mysqli_affected_rows($db) == 1) {

				echo "<div style= ><p>A Client with the details already exist</p><br>
				<a href='client_registration.php'></a>Please go back</div>";
				//header('Location:client_registration.php');
				exit();
				
			}
			
		}

		$query = "INSERT INTO alpha_client (clients_name, date_of_registration, official_phone_number, clients_office_address, clients_email, requires_supervisor ) VALUES ('$clients_name', '$date_of_registration', '$official_phone_number', '$clients_office', '$clients_email', '$requires_supervisor')";
		if (mysqli_query($db, $query)) {
			$client_id =  mysqli_insert_id($db);
		}

		$contact_query = "INSERT INTO alpha_client_contacts (contact_person_name, contact_person_phone_number, contact_email, client_id, clients_name) VALUES";
		for($i = 0; $i < count($_POST['contact_person_name']); $i++){
			$contact_query .= "('{$_POST['contact_person_name'][$i]}', '{$_POST['contact_person_phone_number'][$i]}', '{$_POST['contact_email'][$i]}', $client_id, '$clients_name')";
			$contact_query .= $i == ( count($_POST['contact_person_name']) - 1) ? '' : ',';
		}

        if (!mysqli_query($db, $contact_query)){
        	echo 'Failed to add client records';
        	die();
        }
    
		$beat_query = "INSERT INTO beat (beat_name, beat_address, client_id, clients_name,number_of_guards, cost_per_guard, date_of_deployment, number_of_supervisor, cost_per_supervisor) VALUES";
		for($i = 0; $i < count($_POST['beat_name']); $i++){
			$beat_query .= "('{$_POST['beat_name'][$i]}', '{$_POST['beat_address'][$i]}', $client_id, '$clients_name', '{$_POST['beat_no_of_guards'][$i]}', '{$_POST['beat_amount_per_guard'][$i]}','{$_POST['beat_date_of_deployment'][$i]}',";
			$beat_query .= isset($_POST['beat_number_of_supervisor'][$i]) ? "'{$_POST['beat_number_of_supervisor'][$i]}', ": " ,"; 
			$beat_query .= isset($_POST['beat_amount_per_supervisor'][$i]) ? "'{$_POST['beat_amount_per_supervisor'][$i]}' " : '' ;
			$beat_query .=	")";
			$beat_query .= $i == ( count($_POST['beat_name']) - 1) ? '' : ',';
		}
		// echo "<pre>";
		// var_dump($_POST);
		// echo "</pre>";



		 if (!mysqli_query($db, $beat_query)) {
			echo "Failed to add beat records";
			die();
		}

		function getEndDate($date){
		return date('Y-m-d',strtotime('+30 days',strtotime($date)));
		}

		// fetch all the client's beat from db, add their id and client id and date-start,
		$get_beats = "SELECT id, client_id, date_of_deployment FROM beat WHERE client_id = $client_id";
		 if (!$result = mysqli_query($db, $get_beats)) {
			die('Failed to get beats data for invoice population');
		}

		$invoice_query = "INSERT INTO client_invoice (beat_id, client_id, date_start, date_end) VALUES";
		// got beat data, for each 
		$beats = array();
		while( $row =mysqli_fetch_array($result,MYSQLI_ASSOC) ) {
			$beats[] =$row;
		}


		for($i = 0; $i < count($beats) ; $i++){
			$date_end = getEndDate($beats[$i]['date_of_deployment']);
			$invoice_query .= "( {$beats[$i]['id']}, {$beats[$i]['client_id']}, '{$beats[$i]['date_of_deployment']}', '$date_end' )";
			$invoice_query .= $i == (count($beats) - 1)  ? '' : ',';
		}
		
		if ($result = mysqli_query($db, $invoice_query))
        {
    		$_SESSION["creation-successful"] = "<h6> successful.<br> $clients_name has just been registered as a client with AVK Securities</h6>
    		Name of beat : $beat_name <br>
    		client Name : $clients_name <br>
    		Date of registeration :  $date_of_registration <br>
    		Number of guards : $number_of_guards <br>
    		Number of supervisor : $number_of_supervisor <br>
    		Contact Person : $contact_person_name"; s

    		header('Location:clients_successful.php');
			exit();	
        }

	}

?>