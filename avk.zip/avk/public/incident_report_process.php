<?php
	
	session_start(); // Carbon::today()->subtractMonths(3)->toTimeString();
	

	if(!empty($_POST))
{
	require 'incfile.php';


		// $clients_name = $_POST['clients_name'];
		// $date_of_registration = date('Y-m-d');
		// $official_phone_number = $_POST['official_phone_number'];
		// $clients_office = $_POST['clients_office'];
		// $clients_email = $_POST['clients_email'];
		// $contact_person_name = $_POST['contact_person_name'];
		// $contact_person_phone_number = $_POST['contact_person_phone_number'];
		// $contact_email = $_POST['contact_email'];
		// $requires_supervisor = $_POST['requires_supervisor'];
		// $beat_name = $_POST['beat_name'];
		// $beat_address = $_POST['beat_address'];
		// $number_of_guards = $_POST['number_of_guards'];
		// $amount_per_guard = $_POST['amount_per_guard'];
		// $number_of_supervisor = $_POST['number_of_supervisor'];
		// $amount_per_supervisor = $_POST['amount_per_supervisor'];
		$date_posted = date('Y-m-d');
		$beat_name = $_POST['beat_name'];
		$description = $_POST['description'];
		$month = date("F",strtotime("0 month"));
		$incident_picture = $_POST['$incident_picture'];
		//$balance = $balance;


		// $phone_number = $_POST['phone_number'];
		// $address = $_POST['addr


	


		$query = "INSERT INTO incident_report (date_posted, beat_name, incident, incident_picture, month) VALUES('$date_posted', '$beat_name', '$description', '$incident_picture' '$month')";
		// if (!$result = mysqli_query($db, $query)) {
		// 	echo "noooooo";
		// 	exit();
		// 	# code...
		// }

		if ($result = mysqli_query($db, $query))
        {

        	if (mysqli_affected_rows($db) == 1) 
        	{
        		
        		$_SESSION["creation-successful"] = "<h6>You have just posted an incident report about $beat_name today $date_posted.</h6>";
	            header('Location:incident_report.php');
				exit();

        	}

        	
        }

	}

?>