<?php
session_start();


    require 'incfile.php';
    
  
 
?>


<html>
<head>
	<title>Print Invoice For the Month <?php  echo "date_create()"; ?></title>
	<style type="text/css">
		body {
			font-size: 15px;
			color: #343d44;
			font-family: "segoe-ui", "open-sans", tahoma, arial;
			padding: 0;
			margin: 0;
		}
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;
		}

		h1 {
			margin: 25px auto 0;
			text-align: center;
			text-transform: uppercase;
			font-size: 17px;
		}

		table td {
			transition: all .5s;
		}
		
		/* Table */
		.data-table {
			border-collapse: collapse;
			font-size: 14px;
			min-width: 537px;
		}

		.data-table th, 
		.data-table td {
			border: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.data-table caption {
			margin: 7px;
		}

		/* Table Header */
		.data-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}

		/* Table Body */
		.data-table tbody td {
			color: #353535;
		}
		.data-table tbody td:first-child,
		.data-table tbody td:nth-child(4),
		.data-table tbody td:last-child {
			text-align: right;
		}

		.data-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.data-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
		}

		/* Table Footer */
		.data-table tfoot th {
			background-color: #e5f5ff;
			text-align: right;
		}
		.data-table tfoot th:first-child {
			text-align: left;
		}
		.data-table tbody td:empty
		{
			background-color: #ffcccc;
		}
	</style>

	<?php 

	?>
</head>
<body>
	<div> <h1><b><img src="../images/logo.png" alt="AVK SECURITY" style="max-width: 80px;">AVK SECURITY SERVICES NIG. LTD</b></h1><hr>
	<p style="margin-left: 50px;">496A Cassmance Close,<br> Wuse Zone III<br>Abuja</p>
	<p style="margin-left: 50px;">Phone: +234 09 872 6062, +234 80 64736 280</p></div>
	<div style="margin-left: 1050px;"><b>INVOICE.</b><br><br>
		<?php $date = date('Y-m-d H:i:s'); echo "Date: $date"; ?><br>
		<b>TIN: 12345</b></div>
	
	<table class="data-table">
		<caption class="title"></caption>
		<tbody>
		<?php
		$client_id = $_POST['client_id'];
		$date_end = (string) $_POST['date_end'];
		$date_start =(string) $_POST['date_start'];

		
		// $query = "SELECT alpha_client.clients_name as clients_name, alpha_client.id as client_id, alpha_client.clients_office_address, beat.beat_address, beat.number_of_guards, beat.number_of_supervisor, beat.cost_per_guard, beat.cost_per_supervisor, client_invoice.date_start, client_invoice.date_end FROM beat INNER JOIN alpha_client on beat.client_id= alpha_client.id  INNER JOIN client_invoice on beat.id = client_invoice.beat_id  where alpha_client.id = {$client_id}  AND client_invoice.date_of_payment IS NULL ";
		$query = "SELECT alpha_client.clients_name as clients_name, alpha_client.id as client_id, alpha_client.clients_office_address, beat.beat_address, beat.number_of_guards, beat.number_of_supervisor, beat.cost_per_guard, beat.cost_per_supervisor, client_invoice.date_start, client_invoice.date_end FROM beat INNER JOIN alpha_client on beat.client_id= alpha_client.id INNER JOIN client_invoice on beat.id = client_invoice.beat_id where alpha_client.id = {$client_id} AND client_invoice.date_start BETWEEN CAST('{$date_start}' AS DATE) AND CAST('{$date_end}' AS DATE) AND client_invoice.date_of_payment IS NULL";



		if(!$result = mysqli_query($db, $query)){
			echo '<h2>Error Fetching Data </h2>';

		} else{

			$data = mysqli_fetch_all($result, MYSQLI_ASSOC);
	
		}
		if(!empty($data)){
				echo "<div style='margin-left:50px;'><b> BILL TO:</b> <br>
						{$data[0]['clients_name']} <br>
						{$data[0]['clients_office_address']} <br>

						</div>";
						echo "<table class='data-table'><tr><th>Invoice #</th><th>Description</th><th>Cost Per Guard<br> Monthly</th><th>Number of Guards</th><th>Cost Per Supervisor<br> Monthly</th><th>Number of Supervisors</th><th>Total</th></tr>";
						$description = "Provision of Manned Security Guard <br> at "; 
				$totals = [];
			foreach ($data as $row) {		
					$totalGuard = (int) $row["cost_per_guard"] *  (int) $row["number_of_guards"];
					$totalHeadGuard = (int) $row["cost_per_supervisor"] * (int) $row["number_of_supervisor"];
					$total = $totalGuard + $totalHeadGuard;
					$totals[]= $total;
					$row["date_start"] = date_create($row["date_start"]);
					$row["date_end"] = date_create($row["date_end"]);
					$description = "Provision of Manned Security Guard <br> at {$row['beat_address']} from "; 

			        echo 
			        "<tr><td>AVK/CLI/00".$row["client_id"]."</td><td>".$description. date_format($row["date_start"], "Y/m/d"). ' '. 'TO'. ' ' .date_format($row["date_end"], "Y/m/d")."</td><td>N". number_format($row["cost_per_guard"], 2)."</td><td>".$row["number_of_guards"]."</td><td>N". number_format($row["cost_per_supervisor"], 2)."</td><td>".$row["number_of_supervisor"]."</td><td>N". number_format( $total, 2)."</td></tr>";	
			}
		}


function sumTotals($val1, $val2){
	return (int) $val1 + (int) $val2;
}

?>
<?php if (!empty($data)): ?>
	<tr>
		<td colspan="">Grand Total</td>
		<td colspan="6"><?php echo 'N' . number_format( array_reduce($totals, "sumTotals"), 2) ?></td>
	</tr>
<?php endif ?>
	
</tbody>
</table>
<div style="margin-left: 50px;">
	<h5>Kindly pay through the account details below:<br>
NAME: AVK SECURITY SERVICES NIG.LTD <br>
BANK: UNITY<br>
ACCOUNT NO.: 0025811360
<br>
<br>
<br>

For: AVK Services Nig. Ltd</h5>
	<button onclick="myFunction()">Print this invoice</button>

<script>
function myFunction() {
    window.print();
}
</script>
</div>
		
</body>


</html>