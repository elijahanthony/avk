<?php


    session_start();

    if (isset($_POST)) {
        # code...


    require 'incfile.php';
    


        $query = "INSERT INTO registration_form(name/*, dob, stateoforigin, religion, phonenumber, address, qualification, doe*/) VALUES('$fname')";
        if ($result = mysqli_query($db, $query))
        {
            
            //echo "yes";

            //Used to fetch data from database
            $selectQuery = "SELECT * FROM registration_form";
            if($queryResult = mysqli_query($db, $selectQuery))
            {
                $databaseNames = "";
                while ($row = mysqli_fetch_array($queryResult)) {
                    $databaseNames .= "<p>" . $row["name"] . "</p>";
                }

            }
            $_SESSION["creation-successful"] = "A new guard was successfully created. Added: " . $databaseNames;
            header('Location:guards-form.php');
           exit();

        }


}


?>
