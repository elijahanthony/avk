<?php

session_start();

if (isset($_POST)) {
	
    require 'incfile.php';



//$sql = 'SELECT * FROM alpha_client';
		
//$query = mysqli_query($db, $sql);

//if (!$query) {
	//die ('SQL Error: ' . mysqli_error($conn));
//}



		
		$full_name = $_POST['full_name'];
		//$location = $_POST('location');
		$date_of_offence = date('Y-m-d');
		$offence = $_POST['offence'];
		$num_of_days =$_POST['num_of_days'];
		//$full_name_id = $_SESSION['$full_name_id'];
		//$full_name_id = $_SESSION['$full_name_id'];
		$full_name_id = $_SESSION['$full_name_id'];
		$month = date("F",strtotime("0 month"));

		//$sub_charge_per_day = 500;
		//$month =  date("F",strtotime("0 month")); 

		//$amount = $num_of_days * $sub_charge_per_day;

		$query = "INSERT INTO book_guard (full_name_id, full_name, date_of_offence, month, offence, num_of_days) VALUES ( '$full_name_id', '$full_name', '$date_of_offence', '$month', '$offence', '$num_of_days')";


		// $query = " INSERT INTO book_guard (full_name_id, full_name, date_of_offence, month,  offence, num_of_days)  VALUES ('$full_name_id', '$full_name', '$date_of_offence', '$month', $offence', '$num_of_days')";



		

		if($result = mysqli_query($db, $query))
		{

			
		//if ($result->num_rows > 0)
		if (mysqli_affected_rows($db) == 1) {
			$_SESSION["creation-successful"] = "<h2>$full_name  has <br>been successfully booked for $num_of_days<h2>";
	            header('Location:book_guard.php');
				exit();	
		 	}
		 	else {
		 		echo "does not exist";
		 	}
}
		
//  else {
//     echo "$client_name not found!!! <br> are you sure $client_name is one of our clients? <br> Ensure your spelling is correct";
// }
}

?>
		