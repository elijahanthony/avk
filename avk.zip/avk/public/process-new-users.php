<?php
	
	session_start();


	if(isset($_POST))
	{



    require 'incfile.php';


		$sign_up_firstname = $_POST['sign_up_firstname'];
		$sign_up_lastname = $_POST['sign_up_lastname'];
		$sign_up_username = $_POST['sign_up_username'];
		//$sign_up_email = $_POST['sign_up_email'];
		$sign_up_phone = $_POST['sign_up_phone'];
		$sign_up_department = $_POST['sign_up_department'];
		$sign_up_password = md5($_POST['sign_up_password']);
		$sign_up_retype_password = md5($_POST['sign_up_retype_password']);

		//if

		if($sign_up_retype_password != $sign_up_password )
		{

			$_SESSION['password_error'] = "Passwords do not match!";
			header("Location: registration1.php");
			exit();

		}


		$query = "INSERT INTO umbrella_users(first_name, last_name, username, password, email, phone_number, department) VALUES('$sign_up_firstname', '$sign_up_lastname', '$sign_up_username', '$sign_up_password', '$sign_up_email', '$sign_up_phone', '$sign_up_department')";
		if ($result = mysqli_query($db, $query))
        {

        	if (mysqli_affected_rows($db) == 1) 
        	{
        		
        		$_SESSION["creation-successful"] = "A new user has been successfully created.";
	            header('Location:dashboard1.php');
	            echo "A new user is created successfully";
				exit();

        	}

        	
        }

	}

?>